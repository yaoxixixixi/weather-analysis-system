import site
from time import time
from django.db import models
from django.urls import reverse


class Sites(models.Model):
    """监测站点信息表"""

    site_name = models.CharField(max_length=128, verbose_name='监测点名称')
    site_choices = (
        (0, '国控评价点'),
        (1, '国控，对照点'),
        (2, '市控，工业园区监测点'),
        (3, '市控，区域点'),
    )
    site_props = models.IntegerField(choices=site_choices, verbose_name='点位属性', default=0)
    longitude = models.CharField(max_length=128, verbose_name='经度')
    latitude = models.CharField(max_length=128, verbose_name='维度')
    
    class Meta:
        verbose_name = '监测站点信息'
        verbose_name_plural = '监测站点信息管理'
    
    def get_absolute_url(self):
        return reverse('title-detail-view', args=(self.site_name,))

    def __str__(self):
        return str(self.site_name)

class Factors(models.Model):
    """监测因子信息表"""
    site_name = models.ForeignKey(Sites, on_delete=models.SET_NULL, blank=False, null=True, verbose_name='检测点名称',
                                 db_index=True)
    time = models.DateTimeField(verbose_name='检测时间', auto_now=True)
    lowest_temp = models.FloatField(verbose_name='最低气温')
    highest_temp = models.FloatField(verbose_name='最高气温')
    rainfall = models.CharField(max_length=128, verbose_name='降水')
    wind_choices = (
    (0, '无风'),
    (1, '软风'),
    (2, '轻风'),
    (3, '微风'),
    (4, '和风'),
    (5, '清风'),
    (6, '强风'),
    (7, '劲风'),
    (8, '大风'),
    (9, '烈风'),
    (10, '狂风'),
    (11, '暴风'),
    (12, '台风'),
    (13, '强台风'),
    (14, '超强台风'),
    )
    wind = models.IntegerField(choices=wind_choices, verbose_name='风力', default=0)

    class Meta:
        verbose_name = '监测因子信息'
        verbose_name_plural = '监测因子信息管理'

    def __str__(self):
        return str(self.time)

class Usages(models.Model):
    """数据应用信息表"""
    app_name = models.CharField(max_length=128, verbose_name='授权应用名称')
    site_name = models.ForeignKey(Sites, on_delete=models.SET_NULL, blank=False, null=True, verbose_name='关联监测点',
                                 db_index=True)
    app_details = models.TextField(verbose_name='应用详情')
    developer = models.CharField(max_length=128, verbose_name='开发者')
    tel = models.CharField(max_length=11, verbose_name='联系电话')
    auth_time = models.DateTimeField(verbose_name='授权时间', auto_now=False)

    class Meta:
        verbose_name = '数据应用信息'
        verbose_name_plural = '数据应用信息管理'

    def __str__(self):
        return str(self.app_name)


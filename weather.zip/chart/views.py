# -*- coding: utf-8 -*-
from django.shortcuts import render
from django.http import HttpResponse
 
from matplotlib.figure import Figure
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.dates import DateFormatter
import matplotlib.pyplot as plt
 
import random
import datetime
 
# 折线图对应的的模板
def showlinediagram(request):
    return render(request, 'showlinediagram.html')
def index(request):
    return render(request, 'index.html')


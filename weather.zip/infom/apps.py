from tabnanny import verbose
from django.apps import AppConfig

class InfomConfig(AppConfig):
    name = 'infom'
    verbose_name = "气象数据管理"

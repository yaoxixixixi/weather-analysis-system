from django.shortcuts import render
from django.http.response import JsonResponse
# Create your views here.
def Dataapivew(request):
    return render(request,"index.html",locals())


from django.views.generic import View
from django.contrib.auth.hashers import make_password, check_password
from django.contrib.auth.models import User
from django.contrib.auth import get_user_model  # 要加上这句话不然会报错（1）
User = get_user_model()
import json
class register(View):
    def get(self,request,*args,**kwargs):
        return render(request,"register.html")
    def post(self,request,*args,**kwargs):
        print(request)
        post_data = json.loads(request.body)
        username = post_data.get("username")
        password = post_data.get("password")
        print(username,password)
        User.objects.create(username=username,password=make_password(password),is_active=1,is_staff=1).save()
        msg = "注册成功"
        return JsonResponse({'status':200,'res':"注册成功"})
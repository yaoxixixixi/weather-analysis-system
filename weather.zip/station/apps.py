from django.apps import AppConfig

class StationConfig(AppConfig):
    name = 'station'
    verbose_name = '监测信息管理'
    verbose_name_plural = verbose_name



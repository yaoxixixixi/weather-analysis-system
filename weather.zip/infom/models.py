import site
from time import time
from django.db import models
from django.urls import reverse
from station.models import *


class Lib(models.Model):
    """气象资料表"""
    city = models.ForeignKey(Sites, on_delete=models.SET_NULL, blank=False, null=True, verbose_name='检测区域',
                                 db_index=True)
    earth_lib = models.CharField(max_length=128, verbose_name='地面资料')
    sky_lib = models.CharField(max_length=128, verbose_name='高空资料')
    radiation_lib = models.CharField(max_length=128, verbose_name='辐射资料')
    radar_lib = models.CharField(max_length=128, verbose_name='雷达资料')
    satellite_lib = models.CharField(max_length=128, verbose_name='卫星资料')
    num_lib = models.CharField(max_length=128, verbose_name='数值资料')
   
    class Meta:
        verbose_name = '气象资料信息'
        verbose_name_plural = '气象资料信息管理'

    def __str__(self):
        return str(self.city)

class Advice(models.Model):
    """气象指数信息表"""
    city = models.ForeignKey(Sites, on_delete=models.SET_NULL, blank=False, null=True, verbose_name='检测城市',
                                 db_index=True)
    clothes_inf = models.CharField(max_length=128, verbose_name='穿衣指数')
    uv_inf = models.CharField(max_length=128, verbose_name='紫外线指数')
    carWash_inf = models.CharField(max_length=128, verbose_name='洗车指数')
    ill_inf = models.CharField(max_length=128, verbose_name='感冒指数')

    class Meta:
        verbose_name = '气象指数信息'
        verbose_name_plural = '气象指数信息管理'

    def __str__(self):
        return str(self.city)



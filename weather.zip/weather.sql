/*
Navicat MySQL Data Transfer

Source Server         : xixi
Source Server Version : 50737
Source Host           : localhost:3306
Source Database       : weather

Target Server Type    : MYSQL
Target Server Version : 50737
File Encoding         : 65001

Date: 2022-03-13 22:20:38
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for auth_group
-- ----------------------------
DROP TABLE IF EXISTS `auth_group`;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of auth_group
-- ----------------------------
INSERT INTO `auth_group` VALUES ('2', '普通用户');
INSERT INTO `auth_group` VALUES ('1', '检测管理员');

-- ----------------------------
-- Table structure for auth_group_permissions
-- ----------------------------
DROP TABLE IF EXISTS `auth_group_permissions`;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of auth_group_permissions
-- ----------------------------
INSERT INTO `auth_group_permissions` VALUES ('1', '1', '1');
INSERT INTO `auth_group_permissions` VALUES ('2', '1', '2');
INSERT INTO `auth_group_permissions` VALUES ('3', '1', '3');
INSERT INTO `auth_group_permissions` VALUES ('4', '1', '4');
INSERT INTO `auth_group_permissions` VALUES ('5', '1', '5');
INSERT INTO `auth_group_permissions` VALUES ('6', '1', '6');
INSERT INTO `auth_group_permissions` VALUES ('7', '1', '7');
INSERT INTO `auth_group_permissions` VALUES ('8', '1', '8');
INSERT INTO `auth_group_permissions` VALUES ('9', '1', '9');
INSERT INTO `auth_group_permissions` VALUES ('10', '1', '10');
INSERT INTO `auth_group_permissions` VALUES ('11', '1', '11');
INSERT INTO `auth_group_permissions` VALUES ('12', '1', '12');
INSERT INTO `auth_group_permissions` VALUES ('13', '1', '13');
INSERT INTO `auth_group_permissions` VALUES ('14', '1', '14');
INSERT INTO `auth_group_permissions` VALUES ('15', '1', '15');
INSERT INTO `auth_group_permissions` VALUES ('16', '1', '16');
INSERT INTO `auth_group_permissions` VALUES ('17', '1', '17');
INSERT INTO `auth_group_permissions` VALUES ('18', '1', '18');
INSERT INTO `auth_group_permissions` VALUES ('19', '1', '19');
INSERT INTO `auth_group_permissions` VALUES ('20', '1', '20');
INSERT INTO `auth_group_permissions` VALUES ('21', '1', '21');
INSERT INTO `auth_group_permissions` VALUES ('22', '1', '22');
INSERT INTO `auth_group_permissions` VALUES ('23', '1', '23');
INSERT INTO `auth_group_permissions` VALUES ('24', '1', '24');
INSERT INTO `auth_group_permissions` VALUES ('25', '1', '25');
INSERT INTO `auth_group_permissions` VALUES ('26', '1', '26');
INSERT INTO `auth_group_permissions` VALUES ('27', '1', '27');
INSERT INTO `auth_group_permissions` VALUES ('28', '1', '28');
INSERT INTO `auth_group_permissions` VALUES ('29', '1', '29');
INSERT INTO `auth_group_permissions` VALUES ('30', '1', '30');
INSERT INTO `auth_group_permissions` VALUES ('31', '1', '31');
INSERT INTO `auth_group_permissions` VALUES ('32', '1', '32');
INSERT INTO `auth_group_permissions` VALUES ('33', '1', '33');
INSERT INTO `auth_group_permissions` VALUES ('34', '1', '34');
INSERT INTO `auth_group_permissions` VALUES ('35', '1', '35');
INSERT INTO `auth_group_permissions` VALUES ('36', '1', '36');
INSERT INTO `auth_group_permissions` VALUES ('37', '1', '37');
INSERT INTO `auth_group_permissions` VALUES ('38', '1', '38');
INSERT INTO `auth_group_permissions` VALUES ('39', '1', '39');
INSERT INTO `auth_group_permissions` VALUES ('40', '1', '40');
INSERT INTO `auth_group_permissions` VALUES ('41', '1', '41');
INSERT INTO `auth_group_permissions` VALUES ('42', '1', '42');
INSERT INTO `auth_group_permissions` VALUES ('43', '1', '43');
INSERT INTO `auth_group_permissions` VALUES ('44', '1', '44');
INSERT INTO `auth_group_permissions` VALUES ('47', '2', '8');
INSERT INTO `auth_group_permissions` VALUES ('49', '2', '12');
INSERT INTO `auth_group_permissions` VALUES ('51', '2', '16');
INSERT INTO `auth_group_permissions` VALUES ('52', '2', '20');
INSERT INTO `auth_group_permissions` VALUES ('53', '2', '24');
INSERT INTO `auth_group_permissions` VALUES ('54', '2', '28');
INSERT INTO `auth_group_permissions` VALUES ('45', '2', '32');
INSERT INTO `auth_group_permissions` VALUES ('46', '2', '36');
INSERT INTO `auth_group_permissions` VALUES ('48', '2', '40');
INSERT INTO `auth_group_permissions` VALUES ('50', '2', '44');

-- ----------------------------
-- Table structure for auth_permission
-- ----------------------------
DROP TABLE IF EXISTS `auth_permission`;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of auth_permission
-- ----------------------------
INSERT INTO `auth_permission` VALUES ('1', 'Can add log entry', '1', 'add_logentry');
INSERT INTO `auth_permission` VALUES ('2', 'Can change log entry', '1', 'change_logentry');
INSERT INTO `auth_permission` VALUES ('3', 'Can delete log entry', '1', 'delete_logentry');
INSERT INTO `auth_permission` VALUES ('4', 'Can view log entry', '1', 'view_logentry');
INSERT INTO `auth_permission` VALUES ('5', 'Can add permission', '2', 'add_permission');
INSERT INTO `auth_permission` VALUES ('6', 'Can change permission', '2', 'change_permission');
INSERT INTO `auth_permission` VALUES ('7', 'Can delete permission', '2', 'delete_permission');
INSERT INTO `auth_permission` VALUES ('8', 'Can view permission', '2', 'view_permission');
INSERT INTO `auth_permission` VALUES ('9', 'Can add group', '3', 'add_group');
INSERT INTO `auth_permission` VALUES ('10', 'Can change group', '3', 'change_group');
INSERT INTO `auth_permission` VALUES ('11', 'Can delete group', '3', 'delete_group');
INSERT INTO `auth_permission` VALUES ('12', 'Can view group', '3', 'view_group');
INSERT INTO `auth_permission` VALUES ('13', 'Can add user', '4', 'add_user');
INSERT INTO `auth_permission` VALUES ('14', 'Can change user', '4', 'change_user');
INSERT INTO `auth_permission` VALUES ('15', 'Can delete user', '4', 'delete_user');
INSERT INTO `auth_permission` VALUES ('16', 'Can view user', '4', 'view_user');
INSERT INTO `auth_permission` VALUES ('17', 'Can add content type', '5', 'add_contenttype');
INSERT INTO `auth_permission` VALUES ('18', 'Can change content type', '5', 'change_contenttype');
INSERT INTO `auth_permission` VALUES ('19', 'Can delete content type', '5', 'delete_contenttype');
INSERT INTO `auth_permission` VALUES ('20', 'Can view content type', '5', 'view_contenttype');
INSERT INTO `auth_permission` VALUES ('21', 'Can add session', '6', 'add_session');
INSERT INTO `auth_permission` VALUES ('22', 'Can change session', '6', 'change_session');
INSERT INTO `auth_permission` VALUES ('23', 'Can delete session', '6', 'delete_session');
INSERT INTO `auth_permission` VALUES ('24', 'Can view session', '6', 'view_session');
INSERT INTO `auth_permission` VALUES ('25', 'Can add 监测站点信息', '7', 'add_sites');
INSERT INTO `auth_permission` VALUES ('26', 'Can change 监测站点信息', '7', 'change_sites');
INSERT INTO `auth_permission` VALUES ('27', 'Can delete 监测站点信息', '7', 'delete_sites');
INSERT INTO `auth_permission` VALUES ('28', 'Can view 监测站点信息', '7', 'view_sites');
INSERT INTO `auth_permission` VALUES ('29', 'Can add 数据应用信息', '8', 'add_usages');
INSERT INTO `auth_permission` VALUES ('30', 'Can change 数据应用信息', '8', 'change_usages');
INSERT INTO `auth_permission` VALUES ('31', 'Can delete 数据应用信息', '8', 'delete_usages');
INSERT INTO `auth_permission` VALUES ('32', 'Can view 数据应用信息', '8', 'view_usages');
INSERT INTO `auth_permission` VALUES ('33', 'Can add 监测因子信息', '9', 'add_factors');
INSERT INTO `auth_permission` VALUES ('34', 'Can change 监测因子信息', '9', 'change_factors');
INSERT INTO `auth_permission` VALUES ('35', 'Can delete 监测因子信息', '9', 'delete_factors');
INSERT INTO `auth_permission` VALUES ('36', 'Can view 监测因子信息', '9', 'view_factors');
INSERT INTO `auth_permission` VALUES ('37', 'Can add 气象指数信息', '10', 'add_advice');
INSERT INTO `auth_permission` VALUES ('38', 'Can change 气象指数信息', '10', 'change_advice');
INSERT INTO `auth_permission` VALUES ('39', 'Can delete 气象指数信息', '10', 'delete_advice');
INSERT INTO `auth_permission` VALUES ('40', 'Can view 气象指数信息', '10', 'view_advice');
INSERT INTO `auth_permission` VALUES ('41', 'Can add 气象资料信息', '11', 'add_lib');
INSERT INTO `auth_permission` VALUES ('42', 'Can change 气象资料信息', '11', 'change_lib');
INSERT INTO `auth_permission` VALUES ('43', 'Can delete 气象资料信息', '11', 'delete_lib');
INSERT INTO `auth_permission` VALUES ('44', 'Can view 气象资料信息', '11', 'view_lib');
INSERT INTO `auth_permission` VALUES ('45', 'Can add data', '12', 'add_data');
INSERT INTO `auth_permission` VALUES ('46', 'Can change data', '12', 'change_data');
INSERT INTO `auth_permission` VALUES ('47', 'Can delete data', '12', 'delete_data');
INSERT INTO `auth_permission` VALUES ('48', 'Can view data', '12', 'view_data');
INSERT INTO `auth_permission` VALUES ('49', 'Can add 缓存表', '13', 'add_dimensiontable');
INSERT INTO `auth_permission` VALUES ('50', 'Can change 缓存表', '13', 'change_dimensiontable');
INSERT INTO `auth_permission` VALUES ('51', 'Can delete 缓存表', '13', 'delete_dimensiontable');
INSERT INTO `auth_permission` VALUES ('52', 'Can view 缓存表', '13', 'view_dimensiontable');
INSERT INTO `auth_permission` VALUES ('53', 'Can add 错误日志', '14', 'add_errorlog');
INSERT INTO `auth_permission` VALUES ('54', 'Can change 错误日志', '14', 'change_errorlog');
INSERT INTO `auth_permission` VALUES ('55', 'Can delete 错误日志', '14', 'delete_errorlog');
INSERT INTO `auth_permission` VALUES ('56', 'Can view 错误日志', '14', 'view_errorlog');
INSERT INTO `auth_permission` VALUES ('57', 'Can add 访问记录', '15', 'add_visitlog');
INSERT INTO `auth_permission` VALUES ('58', 'Can change 访问记录', '15', 'change_visitlog');
INSERT INTO `auth_permission` VALUES ('59', 'Can delete 访问记录', '15', 'delete_visitlog');
INSERT INTO `auth_permission` VALUES ('60', 'Can view 访问记录', '15', 'view_visitlog');
INSERT INTO `auth_permission` VALUES ('61', 'Can add 00数据集', '16', 'add_echartdataset');
INSERT INTO `auth_permission` VALUES ('62', 'Can change 00数据集', '16', 'change_echartdataset');
INSERT INTO `auth_permission` VALUES ('63', 'Can delete 00数据集', '16', 'delete_echartdataset');
INSERT INTO `auth_permission` VALUES ('64', 'Can view 00数据集', '16', 'view_echartdataset');
INSERT INTO `auth_permission` VALUES ('65', 'Can add 01仪表盘', '17', 'add_echartdashboardsetup_v2');
INSERT INTO `auth_permission` VALUES ('66', 'Can change 01仪表盘', '17', 'change_echartdashboardsetup_v2');
INSERT INTO `auth_permission` VALUES ('67', 'Can delete 01仪表盘', '17', 'delete_echartdashboardsetup_v2');
INSERT INTO `auth_permission` VALUES ('68', 'Can view 01仪表盘', '17', 'view_echartdashboardsetup_v2');
INSERT INTO `auth_permission` VALUES ('69', 'Can add 06主题', '18', 'add_echarttheme');
INSERT INTO `auth_permission` VALUES ('70', 'Can change 06主题', '18', 'change_echarttheme');
INSERT INTO `auth_permission` VALUES ('71', 'Can delete 06主题', '18', 'delete_echarttheme');
INSERT INTO `auth_permission` VALUES ('72', 'Can view 06主题', '18', 'view_echarttheme');
INSERT INTO `auth_permission` VALUES ('73', 'Can add 03模版', '19', 'add_echarttemplateformat');
INSERT INTO `auth_permission` VALUES ('74', 'Can change 03模版', '19', 'change_echarttemplateformat');
INSERT INTO `auth_permission` VALUES ('75', 'Can delete 03模版', '19', 'delete_echarttemplateformat');
INSERT INTO `auth_permission` VALUES ('76', 'Can view 03模版', '19', 'view_echarttemplateformat');
INSERT INTO `auth_permission` VALUES ('77', 'Can add 07项目', '20', 'add_projectlist');
INSERT INTO `auth_permission` VALUES ('78', 'Can change 07项目', '20', 'change_projectlist');
INSERT INTO `auth_permission` VALUES ('79', 'Can delete 07项目', '20', 'delete_projectlist');
INSERT INTO `auth_permission` VALUES ('80', 'Can view 07项目', '20', 'view_projectlist');
INSERT INTO `auth_permission` VALUES ('81', 'Can add 报表配置', '21', 'add_echartreportsetup');
INSERT INTO `auth_permission` VALUES ('82', 'Can change 报表配置', '21', 'change_echartreportsetup');
INSERT INTO `auth_permission` VALUES ('83', 'Can delete 报表配置', '21', 'delete_echartreportsetup');
INSERT INTO `auth_permission` VALUES ('84', 'Can view 报表配置', '21', 'view_echartreportsetup');
INSERT INTO `auth_permission` VALUES ('85', 'Can add 04图形', '22', 'add_echartformat');
INSERT INTO `auth_permission` VALUES ('86', 'Can change 04图形', '22', 'change_echartformat');
INSERT INTO `auth_permission` VALUES ('87', 'Can delete 04图形', '22', 'delete_echartformat');
INSERT INTO `auth_permission` VALUES ('88', 'Can view 04图形', '22', 'view_echartformat');
INSERT INTO `auth_permission` VALUES ('89', 'Can add 05连接池', '23', 'add_dbsetup');
INSERT INTO `auth_permission` VALUES ('90', 'Can change 05连接池', '23', 'change_dbsetup');
INSERT INTO `auth_permission` VALUES ('91', 'Can delete 05连接池', '23', 'delete_dbsetup');
INSERT INTO `auth_permission` VALUES ('92', 'Can view 05连接池', '23', 'view_dbsetup');

-- ----------------------------
-- Table structure for auth_user
-- ----------------------------
DROP TABLE IF EXISTS `auth_user`;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of auth_user
-- ----------------------------
INSERT INTO `auth_user` VALUES ('1', 'pbkdf2_sha256$180000$C5IGuRqx44jK$dq5HpVIkVGltslw9DPSWD7167XSJB325cJV6Ac5vkGs=', '2022-03-13 21:56:57.690318', '1', 'admin', '', '', '', '1', '1', '2022-03-08 18:58:44.000000');
INSERT INTO `auth_user` VALUES ('2', 'pbkdf2_sha256$180000$hV5qihLBRQrJ$v6Lc5wGu0kzE56A8JAsIxvKfZ3nc6GjVNf87rvIgpME=', '2022-03-13 22:14:17.000000', '0', 'Baic', '', '', '', '1', '1', '2022-03-13 22:07:05.000000');
INSERT INTO `auth_user` VALUES ('3', 'pbkdf2_sha256$180000$NBJfRpqh0x6e$s9F36RYGf2CNvdRlP8cK9M6nxUFMEiuWRXAPh0lDrYw=', '2022-03-13 22:12:06.000000', '1', 'userA', '', '', '', '1', '1', '2022-03-13 22:10:41.000000');

-- ----------------------------
-- Table structure for auth_user_groups
-- ----------------------------
DROP TABLE IF EXISTS `auth_user_groups`;
CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of auth_user_groups
-- ----------------------------
INSERT INTO `auth_user_groups` VALUES ('1', '1', '1');
INSERT INTO `auth_user_groups` VALUES ('2', '2', '2');
INSERT INTO `auth_user_groups` VALUES ('3', '3', '2');

-- ----------------------------
-- Table structure for auth_user_user_permissions
-- ----------------------------
DROP TABLE IF EXISTS `auth_user_user_permissions`;
CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of auth_user_user_permissions
-- ----------------------------
INSERT INTO `auth_user_user_permissions` VALUES ('1', '2', '4');
INSERT INTO `auth_user_user_permissions` VALUES ('2', '2', '8');
INSERT INTO `auth_user_user_permissions` VALUES ('3', '2', '12');
INSERT INTO `auth_user_user_permissions` VALUES ('4', '2', '16');
INSERT INTO `auth_user_user_permissions` VALUES ('5', '2', '20');
INSERT INTO `auth_user_user_permissions` VALUES ('6', '2', '24');
INSERT INTO `auth_user_user_permissions` VALUES ('7', '2', '28');
INSERT INTO `auth_user_user_permissions` VALUES ('8', '2', '32');
INSERT INTO `auth_user_user_permissions` VALUES ('9', '2', '36');
INSERT INTO `auth_user_user_permissions` VALUES ('10', '2', '40');
INSERT INTO `auth_user_user_permissions` VALUES ('11', '2', '44');
INSERT INTO `auth_user_user_permissions` VALUES ('12', '2', '48');
INSERT INTO `auth_user_user_permissions` VALUES ('13', '2', '52');
INSERT INTO `auth_user_user_permissions` VALUES ('14', '2', '56');
INSERT INTO `auth_user_user_permissions` VALUES ('15', '2', '60');
INSERT INTO `auth_user_user_permissions` VALUES ('16', '2', '64');
INSERT INTO `auth_user_user_permissions` VALUES ('17', '2', '68');
INSERT INTO `auth_user_user_permissions` VALUES ('18', '2', '72');
INSERT INTO `auth_user_user_permissions` VALUES ('19', '2', '76');
INSERT INTO `auth_user_user_permissions` VALUES ('20', '2', '80');
INSERT INTO `auth_user_user_permissions` VALUES ('21', '2', '84');
INSERT INTO `auth_user_user_permissions` VALUES ('22', '2', '88');
INSERT INTO `auth_user_user_permissions` VALUES ('23', '2', '92');
INSERT INTO `auth_user_user_permissions` VALUES ('24', '3', '4');
INSERT INTO `auth_user_user_permissions` VALUES ('25', '3', '8');
INSERT INTO `auth_user_user_permissions` VALUES ('26', '3', '12');
INSERT INTO `auth_user_user_permissions` VALUES ('27', '3', '16');
INSERT INTO `auth_user_user_permissions` VALUES ('28', '3', '20');
INSERT INTO `auth_user_user_permissions` VALUES ('29', '3', '24');
INSERT INTO `auth_user_user_permissions` VALUES ('30', '3', '28');
INSERT INTO `auth_user_user_permissions` VALUES ('31', '3', '32');
INSERT INTO `auth_user_user_permissions` VALUES ('32', '3', '36');
INSERT INTO `auth_user_user_permissions` VALUES ('33', '3', '40');
INSERT INTO `auth_user_user_permissions` VALUES ('34', '3', '44');
INSERT INTO `auth_user_user_permissions` VALUES ('35', '3', '48');
INSERT INTO `auth_user_user_permissions` VALUES ('36', '3', '52');
INSERT INTO `auth_user_user_permissions` VALUES ('37', '3', '56');
INSERT INTO `auth_user_user_permissions` VALUES ('38', '3', '60');
INSERT INTO `auth_user_user_permissions` VALUES ('39', '3', '64');
INSERT INTO `auth_user_user_permissions` VALUES ('40', '3', '68');
INSERT INTO `auth_user_user_permissions` VALUES ('41', '3', '72');
INSERT INTO `auth_user_user_permissions` VALUES ('42', '3', '76');
INSERT INTO `auth_user_user_permissions` VALUES ('43', '3', '80');
INSERT INTO `auth_user_user_permissions` VALUES ('44', '3', '84');
INSERT INTO `auth_user_user_permissions` VALUES ('45', '3', '88');
INSERT INTO `auth_user_user_permissions` VALUES ('46', '3', '92');

-- ----------------------------
-- Table structure for datas_data
-- ----------------------------
DROP TABLE IF EXISTS `datas_data`;
CREATE TABLE `datas_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sex` varchar(16) NOT NULL,
  `Placeoforigin` varchar(16) NOT NULL,
  `Terminus` varchar(16) NOT NULL,
  `differentcountries` varchar(16) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of datas_data
-- ----------------------------

-- ----------------------------
-- Table structure for django_admin_log
-- ----------------------------
DROP TABLE IF EXISTS `django_admin_log`;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of django_admin_log
-- ----------------------------
INSERT INTO `django_admin_log` VALUES ('1', '2022-03-08 19:04:24.951952', '1', '宾水西道', '1', '[{\"added\": {}}]', '7', '1');
INSERT INTO `django_admin_log` VALUES ('2', '2022-03-08 19:05:47.606713', '1', '墨迹天气', '1', '[{\"added\": {}}]', '8', '1');
INSERT INTO `django_admin_log` VALUES ('3', '2022-03-08 20:07:55.923313', '1', '检测管理员', '1', '[{\"added\": {}}]', '3', '1');
INSERT INTO `django_admin_log` VALUES ('4', '2022-03-08 20:08:32.723176', '2', '普通用户', '1', '[{\"added\": {}}]', '3', '1');
INSERT INTO `django_admin_log` VALUES ('5', '2022-03-08 20:08:52.138199', '1', 'admin', '2', '[{\"changed\": {\"fields\": [\"Groups\"]}}]', '4', '1');
INSERT INTO `django_admin_log` VALUES ('6', '2022-03-08 22:56:06.563378', '1', '宾水西道', '1', '[{\"added\": {}}]', '10', '1');
INSERT INTO `django_admin_log` VALUES ('7', '2022-03-08 22:56:30.748197', '1', '宾水西道', '1', '[{\"added\": {}}]', '11', '1');
INSERT INTO `django_admin_log` VALUES ('8', '2022-03-08 22:57:05.363604', '2', '嘻嘻天气通', '1', '[{\"added\": {}}]', '8', '1');
INSERT INTO `django_admin_log` VALUES ('9', '2022-03-08 22:57:38.855977', '1', '2022-03-08 22:57:38.852982', '1', '[{\"added\": {}}]', '9', '1');
INSERT INTO `django_admin_log` VALUES ('10', '2022-03-08 22:57:51.916084', '1', '宾水西道', '2', '[{\"changed\": {\"fields\": [\"\\u7ecf\\u5ea6\"]}}]', '7', '1');
INSERT INTO `django_admin_log` VALUES ('11', '2022-03-13 17:58:00.155094', '2', '云岩', '1', '[{\"added\": {}}]', '7', '1');
INSERT INTO `django_admin_log` VALUES ('12', '2022-03-13 18:03:01.232811', '3', '南明', '1', '[{\"added\": {}}]', '7', '1');
INSERT INTO `django_admin_log` VALUES ('13', '2022-03-13 18:03:04.651871', '1', '南明', '2', '[{\"changed\": {\"fields\": [\"\\u68c0\\u6d4b\\u57ce\\u5e02\"]}}]', '10', '1');
INSERT INTO `django_admin_log` VALUES ('14', '2022-03-13 18:03:23.026503', '4', '南明', '1', '[{\"added\": {}}]', '7', '1');
INSERT INTO `django_admin_log` VALUES ('15', '2022-03-13 18:03:56.776129', '4', '贵阳', '2', '[{\"changed\": {\"fields\": [\"\\u76d1\\u6d4b\\u70b9\\u540d\\u79f0\"]}}]', '7', '1');
INSERT INTO `django_admin_log` VALUES ('16', '2022-03-13 18:04:16.696867', '5', '白云', '1', '[{\"added\": {}}]', '7', '1');
INSERT INTO `django_admin_log` VALUES ('17', '2022-03-13 18:04:22.930836', '5', '花溪', '2', '[{\"changed\": {\"fields\": [\"\\u76d1\\u6d4b\\u70b9\\u540d\\u79f0\"]}}]', '7', '1');
INSERT INTO `django_admin_log` VALUES ('18', '2022-03-13 18:04:40.239209', '5', '开阳', '2', '[{\"changed\": {\"fields\": [\"\\u76d1\\u6d4b\\u70b9\\u540d\\u79f0\", \"\\u70b9\\u4f4d\\u5c5e\\u6027\"]}}]', '7', '1');
INSERT INTO `django_admin_log` VALUES ('19', '2022-03-13 18:04:48.856858', '5', '修文', '2', '[{\"changed\": {\"fields\": [\"\\u76d1\\u6d4b\\u70b9\\u540d\\u79f0\", \"\\u70b9\\u4f4d\\u5c5e\\u6027\"]}}]', '7', '1');
INSERT INTO `django_admin_log` VALUES ('20', '2022-03-13 18:05:03.783612', '5', '清镇', '2', '[{\"changed\": {\"fields\": [\"\\u76d1\\u6d4b\\u70b9\\u540d\\u79f0\"]}}]', '7', '1');
INSERT INTO `django_admin_log` VALUES ('21', '2022-03-13 18:05:13.868649', '5', '小河', '2', '[{\"changed\": {\"fields\": [\"\\u76d1\\u6d4b\\u70b9\\u540d\\u79f0\"]}}]', '7', '1');
INSERT INTO `django_admin_log` VALUES ('22', '2022-03-13 19:32:31.528260', '1', '_smartchart', '3', '', '20', '1');
INSERT INTO `django_admin_log` VALUES ('23', '2022-03-13 19:32:49.257928', '1', '固定数据集', '3', '', '16', '1');
INSERT INTO `django_admin_log` VALUES ('24', '2022-03-13 19:34:09.930515', '2', 'xixi', '1', '[{\"added\": {}}]', '23', '1');
INSERT INTO `django_admin_log` VALUES ('25', '2022-03-13 19:34:13.297481', '2', '气象数据', '1', '[{\"added\": {}}]', '16', '1');
INSERT INTO `django_admin_log` VALUES ('26', '2022-03-13 19:34:16.939826', '2', '气象数据', '2', '[]', '16', '1');
INSERT INTO `django_admin_log` VALUES ('27', '2022-03-13 19:34:44.065585', '2', '气象数据', '1', '[{\"added\": {}}]', '17', '1');
INSERT INTO `django_admin_log` VALUES ('28', '2022-03-13 21:01:18.132965', '2', '云岩', '1', '[{\"added\": {}}]', '10', '1');
INSERT INTO `django_admin_log` VALUES ('29', '2022-03-13 21:01:22.457270', '2', '南明', '2', '[{\"changed\": {\"fields\": [\"\\u68c0\\u6d4b\\u57ce\\u5e02\"]}}]', '10', '1');
INSERT INTO `django_admin_log` VALUES ('30', '2022-03-13 21:01:41.961177', '3', '贵阳', '1', '[{\"added\": {}}]', '10', '1');
INSERT INTO `django_admin_log` VALUES ('31', '2022-03-13 21:01:46.662861', '3', '小河', '2', '[{\"changed\": {\"fields\": [\"\\u68c0\\u6d4b\\u57ce\\u5e02\"]}}]', '10', '1');
INSERT INTO `django_admin_log` VALUES ('32', '2022-03-13 21:13:50.184639', '2', '嘻嘻天气', '2', '[{\"changed\": {\"fields\": [\"\\u6388\\u6743\\u5e94\\u7528\\u540d\\u79f0\", \"\\u5173\\u8054\\u76d1\\u6d4b\\u70b9\"]}}]', '8', '1');
INSERT INTO `django_admin_log` VALUES ('33', '2022-03-13 21:13:56.598822', '1', '墨迹天气', '2', '[{\"changed\": {\"fields\": [\"\\u5173\\u8054\\u76d1\\u6d4b\\u70b9\"]}}]', '8', '1');
INSERT INTO `django_admin_log` VALUES ('34', '2022-03-13 21:14:01.934871', '1', '墨迹天气', '2', '[]', '8', '1');
INSERT INTO `django_admin_log` VALUES ('35', '2022-03-13 21:14:13.906567', '1', '华为天气应用', '2', '[{\"changed\": {\"fields\": [\"\\u6388\\u6743\\u5e94\\u7528\\u540d\\u79f0\", \"\\u5e94\\u7528\\u8be6\\u60c5\"]}}]', '8', '1');
INSERT INTO `django_admin_log` VALUES ('36', '2022-03-13 21:14:23.962521', '1', 'ios天气应用', '2', '[{\"changed\": {\"fields\": [\"\\u6388\\u6743\\u5e94\\u7528\\u540d\\u79f0\", \"\\u5173\\u8054\\u76d1\\u6d4b\\u70b9\", \"\\u5e94\\u7528\\u8be6\\u60c5\"]}}]', '8', '1');
INSERT INTO `django_admin_log` VALUES ('37', '2022-03-13 21:14:32.211882', '1', 'ios天气应用', '2', '[]', '8', '1');
INSERT INTO `django_admin_log` VALUES ('38', '2022-03-13 21:14:51.340268', '3', '华为天气应用', '1', '[{\"added\": {}}]', '8', '1');
INSERT INTO `django_admin_log` VALUES ('39', '2022-03-13 21:15:11.966054', '4', '墨迹天气', '1', '[{\"added\": {}}]', '8', '1');
INSERT INTO `django_admin_log` VALUES ('40', '2022-03-13 21:15:28.184155', '1', '2022-03-13 21:15:28.183081', '2', '[{\"changed\": {\"fields\": [\"\\u68c0\\u6d4b\\u70b9\\u540d\\u79f0\"]}}]', '9', '1');
INSERT INTO `django_admin_log` VALUES ('41', '2022-03-13 21:15:37.355191', '1', '南明', '2', '[{\"changed\": {\"fields\": [\"\\u68c0\\u6d4b\\u533a\\u57df\"]}}]', '11', '1');
INSERT INTO `django_admin_log` VALUES ('42', '2022-03-13 21:17:10.688517', '4', '墨迹天气', '2', '[{\"changed\": {\"fields\": [\"\\u5e94\\u7528\\u8be6\\u60c5\"]}}]', '8', '1');
INSERT INTO `django_admin_log` VALUES ('43', '2022-03-13 21:17:30.903460', '2', '2022-03-13 21:17:30.902114', '1', '[{\"added\": {}}]', '9', '1');
INSERT INTO `django_admin_log` VALUES ('44', '2022-03-13 21:17:51.545902', '1', '改成贵州的相关数据', '2', '[{\"changed\": {\"fields\": [\"\\u76d1\\u6d4b\\u70b9\\u540d\\u79f0\", \"\\u70b9\\u4f4d\\u5c5e\\u6027\"]}}]', '7', '1');
INSERT INTO `django_admin_log` VALUES ('45', '2022-03-13 21:58:07.161130', '4', '墨迹天气', '2', '[{\"changed\": {\"fields\": [\"\\u5173\\u8054\\u76d1\\u6d4b\\u70b9\"]}}]', '8', '1');
INSERT INTO `django_admin_log` VALUES ('46', '2022-03-13 22:11:35.314180', '2', 'Baic', '2', '[{\"changed\": {\"fields\": [\"Groups\"]}}]', '4', '1');
INSERT INTO `django_admin_log` VALUES ('47', '2022-03-13 22:11:50.861735', '3', 'userA', '2', '[{\"changed\": {\"fields\": [\"Groups\"]}}]', '4', '1');
INSERT INTO `django_admin_log` VALUES ('48', '2022-03-13 22:13:21.345449', '2', 'Baic', '2', '[{\"changed\": {\"fields\": [\"User permissions\"]}}]', '4', '2');
INSERT INTO `django_admin_log` VALUES ('49', '2022-03-13 22:14:07.729619', '3', 'userA', '2', '[{\"changed\": {\"fields\": [\"User permissions\"]}}]', '4', '2');
INSERT INTO `django_admin_log` VALUES ('50', '2022-03-13 22:14:53.783630', '1', '改成贵州的相关数据', '2', '[{\"changed\": {\"fields\": [\"\\u68c0\\u6d4b\\u533a\\u57df\"]}}]', '11', '2');
INSERT INTO `django_admin_log` VALUES ('51', '2022-03-13 22:15:21.714826', '2', 'Baic', '2', '[{\"changed\": {\"fields\": [\"Superuser status\"]}}]', '4', '2');

-- ----------------------------
-- Table structure for django_content_type
-- ----------------------------
DROP TABLE IF EXISTS `django_content_type`;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of django_content_type
-- ----------------------------
INSERT INTO `django_content_type` VALUES ('1', 'admin', 'logentry');
INSERT INTO `django_content_type` VALUES ('3', 'auth', 'group');
INSERT INTO `django_content_type` VALUES ('2', 'auth', 'permission');
INSERT INTO `django_content_type` VALUES ('4', 'auth', 'user');
INSERT INTO `django_content_type` VALUES ('5', 'contenttypes', 'contenttype');
INSERT INTO `django_content_type` VALUES ('12', 'datas', 'data');
INSERT INTO `django_content_type` VALUES ('23', 'echart', 'dbsetup');
INSERT INTO `django_content_type` VALUES ('13', 'echart', 'dimensiontable');
INSERT INTO `django_content_type` VALUES ('17', 'echart', 'echartdashboardsetup_v2');
INSERT INTO `django_content_type` VALUES ('16', 'echart', 'echartdataset');
INSERT INTO `django_content_type` VALUES ('22', 'echart', 'echartformat');
INSERT INTO `django_content_type` VALUES ('21', 'echart', 'echartreportsetup');
INSERT INTO `django_content_type` VALUES ('19', 'echart', 'echarttemplateformat');
INSERT INTO `django_content_type` VALUES ('18', 'echart', 'echarttheme');
INSERT INTO `django_content_type` VALUES ('14', 'echart', 'errorlog');
INSERT INTO `django_content_type` VALUES ('20', 'echart', 'projectlist');
INSERT INTO `django_content_type` VALUES ('15', 'echart', 'visitlog');
INSERT INTO `django_content_type` VALUES ('10', 'infom', 'advice');
INSERT INTO `django_content_type` VALUES ('11', 'infom', 'lib');
INSERT INTO `django_content_type` VALUES ('6', 'sessions', 'session');
INSERT INTO `django_content_type` VALUES ('9', 'station', 'factors');
INSERT INTO `django_content_type` VALUES ('7', 'station', 'sites');
INSERT INTO `django_content_type` VALUES ('8', 'station', 'usages');

-- ----------------------------
-- Table structure for django_migrations
-- ----------------------------
DROP TABLE IF EXISTS `django_migrations`;
CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of django_migrations
-- ----------------------------
INSERT INTO `django_migrations` VALUES ('1', 'contenttypes', '0001_initial', '2022-03-08 18:58:18.879094');
INSERT INTO `django_migrations` VALUES ('2', 'auth', '0001_initial', '2022-03-08 18:58:18.990489');
INSERT INTO `django_migrations` VALUES ('3', 'admin', '0001_initial', '2022-03-08 18:58:19.197640');
INSERT INTO `django_migrations` VALUES ('4', 'admin', '0002_logentry_remove_auto_add', '2022-03-08 18:58:19.253940');
INSERT INTO `django_migrations` VALUES ('5', 'admin', '0003_logentry_add_action_flag_choices', '2022-03-08 18:58:19.261347');
INSERT INTO `django_migrations` VALUES ('6', 'contenttypes', '0002_remove_content_type_name', '2022-03-08 18:58:19.311406');
INSERT INTO `django_migrations` VALUES ('7', 'auth', '0002_alter_permission_name_max_length', '2022-03-08 18:58:19.344756');
INSERT INTO `django_migrations` VALUES ('8', 'auth', '0003_alter_user_email_max_length', '2022-03-08 18:58:19.374738');
INSERT INTO `django_migrations` VALUES ('9', 'auth', '0004_alter_user_username_opts', '2022-03-08 18:58:19.380799');
INSERT INTO `django_migrations` VALUES ('10', 'auth', '0005_alter_user_last_login_null', '2022-03-08 18:58:19.410734');
INSERT INTO `django_migrations` VALUES ('11', 'auth', '0006_require_contenttypes_0002', '2022-03-08 18:58:19.412738');
INSERT INTO `django_migrations` VALUES ('12', 'auth', '0007_alter_validators_add_error_messages', '2022-03-08 18:58:19.422705');
INSERT INTO `django_migrations` VALUES ('13', 'auth', '0008_alter_user_username_max_length', '2022-03-08 18:58:19.449794');
INSERT INTO `django_migrations` VALUES ('14', 'auth', '0009_alter_user_last_name_max_length', '2022-03-08 18:58:19.479307');
INSERT INTO `django_migrations` VALUES ('15', 'auth', '0010_alter_group_name_max_length', '2022-03-08 18:58:19.506492');
INSERT INTO `django_migrations` VALUES ('16', 'auth', '0011_update_proxy_permissions', '2022-03-08 18:58:19.514036');
INSERT INTO `django_migrations` VALUES ('17', 'sessions', '0001_initial', '2022-03-08 18:58:19.529009');
INSERT INTO `django_migrations` VALUES ('18', 'station', '0001_initial', '2022-03-08 18:58:19.594711');
INSERT INTO `django_migrations` VALUES ('19', 'station', '0002_auto_20220308_1852', '2022-03-08 18:58:19.651724');
INSERT INTO `django_migrations` VALUES ('20', 'station', '0003_remove_usage_site_name', '2022-03-08 18:58:19.679489');
INSERT INTO `django_migrations` VALUES ('21', 'station', '0004_auto_20220308_1855', '2022-03-08 18:58:19.747067');
INSERT INTO `django_migrations` VALUES ('22', 'station', '0005_delete_usages', '2022-03-08 18:58:19.753653');
INSERT INTO `django_migrations` VALUES ('23', 'station', '0006_delete_factors', '2022-03-08 18:58:19.761844');
INSERT INTO `django_migrations` VALUES ('24', 'station', '0007_factors_usages', '2022-03-08 18:58:19.797284');
INSERT INTO `django_migrations` VALUES ('25', 'station', '0008_auto_20220308_1901', '2022-03-08 19:01:19.274925');
INSERT INTO `django_migrations` VALUES ('26', 'infom', '0001_initial', '2022-03-08 20:06:48.490436');
INSERT INTO `django_migrations` VALUES ('27', 'datas', '0001_initial', '2022-03-13 18:54:52.452049');
INSERT INTO `django_migrations` VALUES ('28', 'echart', '0001_initial', '2022-03-13 19:25:27.891902');

-- ----------------------------
-- Table structure for django_session
-- ----------------------------
DROP TABLE IF EXISTS `django_session`;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of django_session
-- ----------------------------
INSERT INTO `django_session` VALUES ('31qk6sbt781ql5gt62hy9aqqfh3yxq8o', 'YzMyMDc4NDA4MjFkMDE3OWMwMTU0MjZmMGFhOGVhZmFiNmNhZWU3MDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIzYzg0OTg1NWNkOGExYzZkNDBjNDE5YTE4MWIxYjgzNjI4MmNkZGJiIiwiX21lbnVzIjoiW3tcIm5hbWVcIjogXCJcXHU2YzE0XFx1OGM2MVxcdTY1NzBcXHU2MzZlXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwiLCBcIm1vZGVsc1wiOiBbe1wibmFtZVwiOiBcIlxcdTZjMTRcXHU4YzYxXFx1NjMwN1xcdTY1NzBcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIiwgXCJ1cmxcIjogXCIvaW5mb20vYWR2aWNlL1wiLCBcImFkZFVybFwiOiBcIi9pbmZvbS9hZHZpY2UvYWRkL1wiLCBcImJyZWFkY3J1bWJzXCI6IFt7XCJuYW1lXCI6IFwiXFx1NmMxNFxcdThjNjFcXHU2NTcwXFx1NjM2ZVxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIn0sIHtcIm5hbWVcIjogXCJcXHU2YzE0XFx1OGM2MVxcdTYzMDdcXHU2NTcwXFx1NGZlMVxcdTYwNmZcXHU3YmExXFx1NzQwNlwiLCBcImljb25cIjogXCJmYXIgZmEtY2lyY2xlXCJ9XSwgXCJlaWRcIjogMTAwMn0sIHtcIm5hbWVcIjogXCJcXHU2YzE0XFx1OGM2MVxcdThkNDRcXHU2NTk5XFx1NGZlMVxcdTYwNmZcXHU3YmExXFx1NzQwNlwiLCBcImljb25cIjogXCJmYXIgZmEtY2lyY2xlXCIsIFwidXJsXCI6IFwiL2luZm9tL2xpYi9cIiwgXCJhZGRVcmxcIjogXCIvaW5mb20vbGliL2FkZC9cIiwgXCJicmVhZGNydW1ic1wiOiBbe1wibmFtZVwiOiBcIlxcdTZjMTRcXHU4YzYxXFx1NjU3MFxcdTYzNmVcXHU3YmExXFx1NzQwNlwiLCBcImljb25cIjogXCJmYXIgZmEtY2lyY2xlXCJ9LCB7XCJuYW1lXCI6IFwiXFx1NmMxNFxcdThjNjFcXHU4ZDQ0XFx1NjU5OVxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwifV0sIFwiZWlkXCI6IDEwMDN9XSwgXCJlaWRcIjogMTAwMX0sIHtcIm5hbWVcIjogXCJcXHU3NmQxXFx1NmQ0YlxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwiLCBcIm1vZGVsc1wiOiBbe1wibmFtZVwiOiBcIlxcdTY1NzBcXHU2MzZlXFx1NWU5NFxcdTc1MjhcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIiwgXCJ1cmxcIjogXCIvc3RhdGlvbi91c2FnZXMvXCIsIFwiYWRkVXJsXCI6IFwiL3N0YXRpb24vdXNhZ2VzL2FkZC9cIiwgXCJicmVhZGNydW1ic1wiOiBbe1wibmFtZVwiOiBcIlxcdTc2ZDFcXHU2ZDRiXFx1NGZlMVxcdTYwNmZcXHU3YmExXFx1NzQwNlwiLCBcImljb25cIjogXCJmYXIgZmEtY2lyY2xlXCJ9LCB7XCJuYW1lXCI6IFwiXFx1NjU3MFxcdTYzNmVcXHU1ZTk0XFx1NzUyOFxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwifV0sIFwiZWlkXCI6IDEwMDV9LCB7XCJuYW1lXCI6IFwiXFx1NzZkMVxcdTZkNGJcXHU1NmUwXFx1NWI1MFxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwiLCBcInVybFwiOiBcIi9zdGF0aW9uL2ZhY3RvcnMvXCIsIFwiYWRkVXJsXCI6IFwiL3N0YXRpb24vZmFjdG9ycy9hZGQvXCIsIFwiYnJlYWRjcnVtYnNcIjogW3tcIm5hbWVcIjogXCJcXHU3NmQxXFx1NmQ0YlxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwifSwge1wibmFtZVwiOiBcIlxcdTc2ZDFcXHU2ZDRiXFx1NTZlMFxcdTViNTBcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIn1dLCBcImVpZFwiOiAxMDA2fSwge1wibmFtZVwiOiBcIlxcdTc2ZDFcXHU2ZDRiXFx1N2FkOVxcdTcwYjlcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIiwgXCJ1cmxcIjogXCIvc3RhdGlvbi9zaXRlcy9cIiwgXCJhZGRVcmxcIjogXCIvc3RhdGlvbi9zaXRlcy9hZGQvXCIsIFwiYnJlYWRjcnVtYnNcIjogW3tcIm5hbWVcIjogXCJcXHU3NmQxXFx1NmQ0YlxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwifSwge1wibmFtZVwiOiBcIlxcdTc2ZDFcXHU2ZDRiXFx1N2FkOVxcdTcwYjlcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIn1dLCBcImVpZFwiOiAxMDA3fV0sIFwiZWlkXCI6IDEwMDR9LCB7XCJuYW1lXCI6IFwiXFx1OGJhNFxcdThiYzFcXHU1NDhjXFx1NjM4OFxcdTY3NDNcIiwgXCJpY29uXCI6IFwiZmFzIGZhLXNoaWVsZC1hbHRcIiwgXCJtb2RlbHNcIjogW3tcIm5hbWVcIjogXCJcXHU3NTI4XFx1NjIzN1wiLCBcImljb25cIjogXCJmYXIgZmEtdXNlclwiLCBcInVybFwiOiBcIi9hdXRoL3VzZXIvXCIsIFwiYWRkVXJsXCI6IFwiL2F1dGgvdXNlci9hZGQvXCIsIFwiYnJlYWRjcnVtYnNcIjogW3tcIm5hbWVcIjogXCJcXHU4YmE0XFx1OGJjMVxcdTU0OGNcXHU2Mzg4XFx1Njc0M1wiLCBcImljb25cIjogXCJmYXMgZmEtc2hpZWxkLWFsdFwifSwge1wibmFtZVwiOiBcIlxcdTc1MjhcXHU2MjM3XCIsIFwiaWNvblwiOiBcImZhciBmYS11c2VyXCJ9XSwgXCJlaWRcIjogMTAwOX0sIHtcIm5hbWVcIjogXCJcXHU3ZWM0XCIsIFwiaWNvblwiOiBcImZhcyBmYS11c2Vycy1jb2dcIiwgXCJ1cmxcIjogXCIvYXV0aC9ncm91cC9cIiwgXCJhZGRVcmxcIjogXCIvYXV0aC9ncm91cC9hZGQvXCIsIFwiYnJlYWRjcnVtYnNcIjogW3tcIm5hbWVcIjogXCJcXHU4YmE0XFx1OGJjMVxcdTU0OGNcXHU2Mzg4XFx1Njc0M1wiLCBcImljb25cIjogXCJmYXMgZmEtc2hpZWxkLWFsdFwifSwge1wibmFtZVwiOiBcIlxcdTdlYzRcIiwgXCJpY29uXCI6IFwiZmFzIGZhLXVzZXJzLWNvZ1wifV0sIFwiZWlkXCI6IDEwMTB9XSwgXCJlaWRcIjogMTAwOH1dIiwic2ltcGxldWlfMjAyMjAzMTMiOnRydWV9', '2022-03-27 22:06:21.611486');
INSERT INTO `django_session` VALUES ('8086givba58uuukg9xp2hbkcjmeu7wu5', 'YzMyMDc4NDA4MjFkMDE3OWMwMTU0MjZmMGFhOGVhZmFiNmNhZWU3MDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIzYzg0OTg1NWNkOGExYzZkNDBjNDE5YTE4MWIxYjgzNjI4MmNkZGJiIiwiX21lbnVzIjoiW3tcIm5hbWVcIjogXCJcXHU2YzE0XFx1OGM2MVxcdTY1NzBcXHU2MzZlXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwiLCBcIm1vZGVsc1wiOiBbe1wibmFtZVwiOiBcIlxcdTZjMTRcXHU4YzYxXFx1NjMwN1xcdTY1NzBcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIiwgXCJ1cmxcIjogXCIvaW5mb20vYWR2aWNlL1wiLCBcImFkZFVybFwiOiBcIi9pbmZvbS9hZHZpY2UvYWRkL1wiLCBcImJyZWFkY3J1bWJzXCI6IFt7XCJuYW1lXCI6IFwiXFx1NmMxNFxcdThjNjFcXHU2NTcwXFx1NjM2ZVxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIn0sIHtcIm5hbWVcIjogXCJcXHU2YzE0XFx1OGM2MVxcdTYzMDdcXHU2NTcwXFx1NGZlMVxcdTYwNmZcXHU3YmExXFx1NzQwNlwiLCBcImljb25cIjogXCJmYXIgZmEtY2lyY2xlXCJ9XSwgXCJlaWRcIjogMTAwMn0sIHtcIm5hbWVcIjogXCJcXHU2YzE0XFx1OGM2MVxcdThkNDRcXHU2NTk5XFx1NGZlMVxcdTYwNmZcXHU3YmExXFx1NzQwNlwiLCBcImljb25cIjogXCJmYXIgZmEtY2lyY2xlXCIsIFwidXJsXCI6IFwiL2luZm9tL2xpYi9cIiwgXCJhZGRVcmxcIjogXCIvaW5mb20vbGliL2FkZC9cIiwgXCJicmVhZGNydW1ic1wiOiBbe1wibmFtZVwiOiBcIlxcdTZjMTRcXHU4YzYxXFx1NjU3MFxcdTYzNmVcXHU3YmExXFx1NzQwNlwiLCBcImljb25cIjogXCJmYXIgZmEtY2lyY2xlXCJ9LCB7XCJuYW1lXCI6IFwiXFx1NmMxNFxcdThjNjFcXHU4ZDQ0XFx1NjU5OVxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwifV0sIFwiZWlkXCI6IDEwMDN9XSwgXCJlaWRcIjogMTAwMX0sIHtcIm5hbWVcIjogXCJcXHU3NmQxXFx1NmQ0YlxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwiLCBcIm1vZGVsc1wiOiBbe1wibmFtZVwiOiBcIlxcdTY1NzBcXHU2MzZlXFx1NWU5NFxcdTc1MjhcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIiwgXCJ1cmxcIjogXCIvc3RhdGlvbi91c2FnZXMvXCIsIFwiYWRkVXJsXCI6IFwiL3N0YXRpb24vdXNhZ2VzL2FkZC9cIiwgXCJicmVhZGNydW1ic1wiOiBbe1wibmFtZVwiOiBcIlxcdTc2ZDFcXHU2ZDRiXFx1NGZlMVxcdTYwNmZcXHU3YmExXFx1NzQwNlwiLCBcImljb25cIjogXCJmYXIgZmEtY2lyY2xlXCJ9LCB7XCJuYW1lXCI6IFwiXFx1NjU3MFxcdTYzNmVcXHU1ZTk0XFx1NzUyOFxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwifV0sIFwiZWlkXCI6IDEwMDV9LCB7XCJuYW1lXCI6IFwiXFx1NzZkMVxcdTZkNGJcXHU1NmUwXFx1NWI1MFxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwiLCBcInVybFwiOiBcIi9zdGF0aW9uL2ZhY3RvcnMvXCIsIFwiYWRkVXJsXCI6IFwiL3N0YXRpb24vZmFjdG9ycy9hZGQvXCIsIFwiYnJlYWRjcnVtYnNcIjogW3tcIm5hbWVcIjogXCJcXHU3NmQxXFx1NmQ0YlxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwifSwge1wibmFtZVwiOiBcIlxcdTc2ZDFcXHU2ZDRiXFx1NTZlMFxcdTViNTBcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIn1dLCBcImVpZFwiOiAxMDA2fSwge1wibmFtZVwiOiBcIlxcdTc2ZDFcXHU2ZDRiXFx1N2FkOVxcdTcwYjlcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIiwgXCJ1cmxcIjogXCIvc3RhdGlvbi9zaXRlcy9cIiwgXCJhZGRVcmxcIjogXCIvc3RhdGlvbi9zaXRlcy9hZGQvXCIsIFwiYnJlYWRjcnVtYnNcIjogW3tcIm5hbWVcIjogXCJcXHU3NmQxXFx1NmQ0YlxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwifSwge1wibmFtZVwiOiBcIlxcdTc2ZDFcXHU2ZDRiXFx1N2FkOVxcdTcwYjlcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIn1dLCBcImVpZFwiOiAxMDA3fV0sIFwiZWlkXCI6IDEwMDR9LCB7XCJuYW1lXCI6IFwiXFx1OGJhNFxcdThiYzFcXHU1NDhjXFx1NjM4OFxcdTY3NDNcIiwgXCJpY29uXCI6IFwiZmFzIGZhLXNoaWVsZC1hbHRcIiwgXCJtb2RlbHNcIjogW3tcIm5hbWVcIjogXCJcXHU3NTI4XFx1NjIzN1wiLCBcImljb25cIjogXCJmYXIgZmEtdXNlclwiLCBcInVybFwiOiBcIi9hdXRoL3VzZXIvXCIsIFwiYWRkVXJsXCI6IFwiL2F1dGgvdXNlci9hZGQvXCIsIFwiYnJlYWRjcnVtYnNcIjogW3tcIm5hbWVcIjogXCJcXHU4YmE0XFx1OGJjMVxcdTU0OGNcXHU2Mzg4XFx1Njc0M1wiLCBcImljb25cIjogXCJmYXMgZmEtc2hpZWxkLWFsdFwifSwge1wibmFtZVwiOiBcIlxcdTc1MjhcXHU2MjM3XCIsIFwiaWNvblwiOiBcImZhciBmYS11c2VyXCJ9XSwgXCJlaWRcIjogMTAwOX0sIHtcIm5hbWVcIjogXCJcXHU3ZWM0XCIsIFwiaWNvblwiOiBcImZhcyBmYS11c2Vycy1jb2dcIiwgXCJ1cmxcIjogXCIvYXV0aC9ncm91cC9cIiwgXCJhZGRVcmxcIjogXCIvYXV0aC9ncm91cC9hZGQvXCIsIFwiYnJlYWRjcnVtYnNcIjogW3tcIm5hbWVcIjogXCJcXHU4YmE0XFx1OGJjMVxcdTU0OGNcXHU2Mzg4XFx1Njc0M1wiLCBcImljb25cIjogXCJmYXMgZmEtc2hpZWxkLWFsdFwifSwge1wibmFtZVwiOiBcIlxcdTdlYzRcIiwgXCJpY29uXCI6IFwiZmFzIGZhLXVzZXJzLWNvZ1wifV0sIFwiZWlkXCI6IDEwMTB9XSwgXCJlaWRcIjogMTAwOH1dIiwic2ltcGxldWlfMjAyMjAzMTMiOnRydWV9', '2022-03-27 20:06:49.727258');
INSERT INTO `django_session` VALUES ('aloa89f17ep6rkoexwkrlbomonecupcm', 'YzMyMDc4NDA4MjFkMDE3OWMwMTU0MjZmMGFhOGVhZmFiNmNhZWU3MDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIzYzg0OTg1NWNkOGExYzZkNDBjNDE5YTE4MWIxYjgzNjI4MmNkZGJiIiwiX21lbnVzIjoiW3tcIm5hbWVcIjogXCJcXHU2YzE0XFx1OGM2MVxcdTY1NzBcXHU2MzZlXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwiLCBcIm1vZGVsc1wiOiBbe1wibmFtZVwiOiBcIlxcdTZjMTRcXHU4YzYxXFx1NjMwN1xcdTY1NzBcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIiwgXCJ1cmxcIjogXCIvaW5mb20vYWR2aWNlL1wiLCBcImFkZFVybFwiOiBcIi9pbmZvbS9hZHZpY2UvYWRkL1wiLCBcImJyZWFkY3J1bWJzXCI6IFt7XCJuYW1lXCI6IFwiXFx1NmMxNFxcdThjNjFcXHU2NTcwXFx1NjM2ZVxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIn0sIHtcIm5hbWVcIjogXCJcXHU2YzE0XFx1OGM2MVxcdTYzMDdcXHU2NTcwXFx1NGZlMVxcdTYwNmZcXHU3YmExXFx1NzQwNlwiLCBcImljb25cIjogXCJmYXIgZmEtY2lyY2xlXCJ9XSwgXCJlaWRcIjogMTAwMn0sIHtcIm5hbWVcIjogXCJcXHU2YzE0XFx1OGM2MVxcdThkNDRcXHU2NTk5XFx1NGZlMVxcdTYwNmZcXHU3YmExXFx1NzQwNlwiLCBcImljb25cIjogXCJmYXIgZmEtY2lyY2xlXCIsIFwidXJsXCI6IFwiL2luZm9tL2xpYi9cIiwgXCJhZGRVcmxcIjogXCIvaW5mb20vbGliL2FkZC9cIiwgXCJicmVhZGNydW1ic1wiOiBbe1wibmFtZVwiOiBcIlxcdTZjMTRcXHU4YzYxXFx1NjU3MFxcdTYzNmVcXHU3YmExXFx1NzQwNlwiLCBcImljb25cIjogXCJmYXIgZmEtY2lyY2xlXCJ9LCB7XCJuYW1lXCI6IFwiXFx1NmMxNFxcdThjNjFcXHU4ZDQ0XFx1NjU5OVxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwifV0sIFwiZWlkXCI6IDEwMDN9XSwgXCJlaWRcIjogMTAwMX0sIHtcIm5hbWVcIjogXCJcXHU3NmQxXFx1NmQ0YlxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwiLCBcIm1vZGVsc1wiOiBbe1wibmFtZVwiOiBcIlxcdTY1NzBcXHU2MzZlXFx1NWU5NFxcdTc1MjhcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIiwgXCJ1cmxcIjogXCIvc3RhdGlvbi91c2FnZXMvXCIsIFwiYWRkVXJsXCI6IFwiL3N0YXRpb24vdXNhZ2VzL2FkZC9cIiwgXCJicmVhZGNydW1ic1wiOiBbe1wibmFtZVwiOiBcIlxcdTc2ZDFcXHU2ZDRiXFx1NGZlMVxcdTYwNmZcXHU3YmExXFx1NzQwNlwiLCBcImljb25cIjogXCJmYXIgZmEtY2lyY2xlXCJ9LCB7XCJuYW1lXCI6IFwiXFx1NjU3MFxcdTYzNmVcXHU1ZTk0XFx1NzUyOFxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwifV0sIFwiZWlkXCI6IDEwMDV9LCB7XCJuYW1lXCI6IFwiXFx1NzZkMVxcdTZkNGJcXHU1NmUwXFx1NWI1MFxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwiLCBcInVybFwiOiBcIi9zdGF0aW9uL2ZhY3RvcnMvXCIsIFwiYWRkVXJsXCI6IFwiL3N0YXRpb24vZmFjdG9ycy9hZGQvXCIsIFwiYnJlYWRjcnVtYnNcIjogW3tcIm5hbWVcIjogXCJcXHU3NmQxXFx1NmQ0YlxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwifSwge1wibmFtZVwiOiBcIlxcdTc2ZDFcXHU2ZDRiXFx1NTZlMFxcdTViNTBcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIn1dLCBcImVpZFwiOiAxMDA2fSwge1wibmFtZVwiOiBcIlxcdTc2ZDFcXHU2ZDRiXFx1N2FkOVxcdTcwYjlcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIiwgXCJ1cmxcIjogXCIvc3RhdGlvbi9zaXRlcy9cIiwgXCJhZGRVcmxcIjogXCIvc3RhdGlvbi9zaXRlcy9hZGQvXCIsIFwiYnJlYWRjcnVtYnNcIjogW3tcIm5hbWVcIjogXCJcXHU3NmQxXFx1NmQ0YlxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwifSwge1wibmFtZVwiOiBcIlxcdTc2ZDFcXHU2ZDRiXFx1N2FkOVxcdTcwYjlcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIn1dLCBcImVpZFwiOiAxMDA3fV0sIFwiZWlkXCI6IDEwMDR9LCB7XCJuYW1lXCI6IFwiXFx1OGJhNFxcdThiYzFcXHU1NDhjXFx1NjM4OFxcdTY3NDNcIiwgXCJpY29uXCI6IFwiZmFzIGZhLXNoaWVsZC1hbHRcIiwgXCJtb2RlbHNcIjogW3tcIm5hbWVcIjogXCJcXHU3NTI4XFx1NjIzN1wiLCBcImljb25cIjogXCJmYXIgZmEtdXNlclwiLCBcInVybFwiOiBcIi9hdXRoL3VzZXIvXCIsIFwiYWRkVXJsXCI6IFwiL2F1dGgvdXNlci9hZGQvXCIsIFwiYnJlYWRjcnVtYnNcIjogW3tcIm5hbWVcIjogXCJcXHU4YmE0XFx1OGJjMVxcdTU0OGNcXHU2Mzg4XFx1Njc0M1wiLCBcImljb25cIjogXCJmYXMgZmEtc2hpZWxkLWFsdFwifSwge1wibmFtZVwiOiBcIlxcdTc1MjhcXHU2MjM3XCIsIFwiaWNvblwiOiBcImZhciBmYS11c2VyXCJ9XSwgXCJlaWRcIjogMTAwOX0sIHtcIm5hbWVcIjogXCJcXHU3ZWM0XCIsIFwiaWNvblwiOiBcImZhcyBmYS11c2Vycy1jb2dcIiwgXCJ1cmxcIjogXCIvYXV0aC9ncm91cC9cIiwgXCJhZGRVcmxcIjogXCIvYXV0aC9ncm91cC9hZGQvXCIsIFwiYnJlYWRjcnVtYnNcIjogW3tcIm5hbWVcIjogXCJcXHU4YmE0XFx1OGJjMVxcdTU0OGNcXHU2Mzg4XFx1Njc0M1wiLCBcImljb25cIjogXCJmYXMgZmEtc2hpZWxkLWFsdFwifSwge1wibmFtZVwiOiBcIlxcdTdlYzRcIiwgXCJpY29uXCI6IFwiZmFzIGZhLXVzZXJzLWNvZ1wifV0sIFwiZWlkXCI6IDEwMTB9XSwgXCJlaWRcIjogMTAwOH1dIiwic2ltcGxldWlfMjAyMjAzMTMiOnRydWV9', '2022-03-27 19:58:06.214591');
INSERT INTO `django_session` VALUES ('cr965evwk6on0x5yzgqs9xdit7zv33sq', 'YjZiY2Q0MTg1NWRjODEyYWE1M2UwMjVkMmFlMTVmZjMwZjQ3MjZiMjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIzYzg0OTg1NWNkOGExYzZkNDBjNDE5YTE4MWIxYjgzNjI4MmNkZGJiIiwiX21lbnVzIjoiW3tcIm5hbWVcIjogXCJcXHU2YzE0XFx1OGM2MVxcdTY1NzBcXHU2MzZlXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwiLCBcIm1vZGVsc1wiOiBbe1wibmFtZVwiOiBcIlxcdTZjMTRcXHU4YzYxXFx1NjMwN1xcdTY1NzBcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIiwgXCJ1cmxcIjogXCIvaW5mb20vYWR2aWNlL1wiLCBcImFkZFVybFwiOiBcIi9pbmZvbS9hZHZpY2UvYWRkL1wiLCBcImJyZWFkY3J1bWJzXCI6IFt7XCJuYW1lXCI6IFwiXFx1NmMxNFxcdThjNjFcXHU2NTcwXFx1NjM2ZVxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIn0sIHtcIm5hbWVcIjogXCJcXHU2YzE0XFx1OGM2MVxcdTYzMDdcXHU2NTcwXFx1NGZlMVxcdTYwNmZcXHU3YmExXFx1NzQwNlwiLCBcImljb25cIjogXCJmYXIgZmEtY2lyY2xlXCJ9XSwgXCJlaWRcIjogMTAwMn0sIHtcIm5hbWVcIjogXCJcXHU2YzE0XFx1OGM2MVxcdThkNDRcXHU2NTk5XFx1NGZlMVxcdTYwNmZcXHU3YmExXFx1NzQwNlwiLCBcImljb25cIjogXCJmYXIgZmEtY2lyY2xlXCIsIFwidXJsXCI6IFwiL2luZm9tL2xpYi9cIiwgXCJhZGRVcmxcIjogXCIvaW5mb20vbGliL2FkZC9cIiwgXCJicmVhZGNydW1ic1wiOiBbe1wibmFtZVwiOiBcIlxcdTZjMTRcXHU4YzYxXFx1NjU3MFxcdTYzNmVcXHU3YmExXFx1NzQwNlwiLCBcImljb25cIjogXCJmYXIgZmEtY2lyY2xlXCJ9LCB7XCJuYW1lXCI6IFwiXFx1NmMxNFxcdThjNjFcXHU4ZDQ0XFx1NjU5OVxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwifV0sIFwiZWlkXCI6IDEwMDN9XSwgXCJlaWRcIjogMTAwMX0sIHtcIm5hbWVcIjogXCJcXHU3NmQxXFx1NmQ0YlxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwiLCBcIm1vZGVsc1wiOiBbe1wibmFtZVwiOiBcIlxcdTY1NzBcXHU2MzZlXFx1NWU5NFxcdTc1MjhcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIiwgXCJ1cmxcIjogXCIvc3RhdGlvbi91c2FnZXMvXCIsIFwiYWRkVXJsXCI6IFwiL3N0YXRpb24vdXNhZ2VzL2FkZC9cIiwgXCJicmVhZGNydW1ic1wiOiBbe1wibmFtZVwiOiBcIlxcdTc2ZDFcXHU2ZDRiXFx1NGZlMVxcdTYwNmZcXHU3YmExXFx1NzQwNlwiLCBcImljb25cIjogXCJmYXIgZmEtY2lyY2xlXCJ9LCB7XCJuYW1lXCI6IFwiXFx1NjU3MFxcdTYzNmVcXHU1ZTk0XFx1NzUyOFxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwifV0sIFwiZWlkXCI6IDEwMDV9LCB7XCJuYW1lXCI6IFwiXFx1NzZkMVxcdTZkNGJcXHU1NmUwXFx1NWI1MFxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwiLCBcInVybFwiOiBcIi9zdGF0aW9uL2ZhY3RvcnMvXCIsIFwiYWRkVXJsXCI6IFwiL3N0YXRpb24vZmFjdG9ycy9hZGQvXCIsIFwiYnJlYWRjcnVtYnNcIjogW3tcIm5hbWVcIjogXCJcXHU3NmQxXFx1NmQ0YlxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwifSwge1wibmFtZVwiOiBcIlxcdTc2ZDFcXHU2ZDRiXFx1NTZlMFxcdTViNTBcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIn1dLCBcImVpZFwiOiAxMDA2fSwge1wibmFtZVwiOiBcIlxcdTc2ZDFcXHU2ZDRiXFx1N2FkOVxcdTcwYjlcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIiwgXCJ1cmxcIjogXCIvc3RhdGlvbi9zaXRlcy9cIiwgXCJhZGRVcmxcIjogXCIvc3RhdGlvbi9zaXRlcy9hZGQvXCIsIFwiYnJlYWRjcnVtYnNcIjogW3tcIm5hbWVcIjogXCJcXHU3NmQxXFx1NmQ0YlxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwifSwge1wibmFtZVwiOiBcIlxcdTc2ZDFcXHU2ZDRiXFx1N2FkOVxcdTcwYjlcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIn1dLCBcImVpZFwiOiAxMDA3fV0sIFwiZWlkXCI6IDEwMDR9LCB7XCJuYW1lXCI6IFwiXFx1OGJhNFxcdThiYzFcXHU1NDhjXFx1NjM4OFxcdTY3NDNcIiwgXCJpY29uXCI6IFwiZmFzIGZhLXNoaWVsZC1hbHRcIiwgXCJtb2RlbHNcIjogW3tcIm5hbWVcIjogXCJcXHU3NTI4XFx1NjIzN1wiLCBcImljb25cIjogXCJmYXIgZmEtdXNlclwiLCBcInVybFwiOiBcIi9hdXRoL3VzZXIvXCIsIFwiYWRkVXJsXCI6IFwiL2F1dGgvdXNlci9hZGQvXCIsIFwiYnJlYWRjcnVtYnNcIjogW3tcIm5hbWVcIjogXCJcXHU4YmE0XFx1OGJjMVxcdTU0OGNcXHU2Mzg4XFx1Njc0M1wiLCBcImljb25cIjogXCJmYXMgZmEtc2hpZWxkLWFsdFwifSwge1wibmFtZVwiOiBcIlxcdTc1MjhcXHU2MjM3XCIsIFwiaWNvblwiOiBcImZhciBmYS11c2VyXCJ9XSwgXCJlaWRcIjogMTAwOX0sIHtcIm5hbWVcIjogXCJcXHU3ZWM0XCIsIFwiaWNvblwiOiBcImZhcyBmYS11c2Vycy1jb2dcIiwgXCJ1cmxcIjogXCIvYXV0aC9ncm91cC9cIiwgXCJhZGRVcmxcIjogXCIvYXV0aC9ncm91cC9hZGQvXCIsIFwiYnJlYWRjcnVtYnNcIjogW3tcIm5hbWVcIjogXCJcXHU4YmE0XFx1OGJjMVxcdTU0OGNcXHU2Mzg4XFx1Njc0M1wiLCBcImljb25cIjogXCJmYXMgZmEtc2hpZWxkLWFsdFwifSwge1wibmFtZVwiOiBcIlxcdTdlYzRcIiwgXCJpY29uXCI6IFwiZmFzIGZhLXVzZXJzLWNvZ1wifV0sIFwiZWlkXCI6IDEwMTB9XSwgXCJlaWRcIjogMTAwOH1dIiwic2ltcGxldWlfMjAyMjAzMDkiOnRydWUsInNpbXBsZXVpXzIwMjIwMzEzIjp0cnVlfQ==', '2022-03-27 19:06:43.267250');
INSERT INTO `django_session` VALUES ('ddtimnr8mhw41yjbj3023pckpwsdjnpy', 'YTZjZTYzMDgyYzEwYmIwODRlNDI1OGEyM2VjYmNlYTQ4ZjYyMzA0Njp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIzYzg0OTg1NWNkOGExYzZkNDBjNDE5YTE4MWIxYjgzNjI4MmNkZGJiIiwiX21lbnVzIjoiW3tcIm5hbWVcIjogXCJTbWFydENoYXJ0XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIiwgXCJtb2RlbHNcIjogW3tcIm5hbWVcIjogXCIwMFxcdTY1NzBcXHU2MzZlXFx1OTZjNlwiLCBcImljb25cIjogXCJmYXIgZmEtY2lyY2xlXCIsIFwidXJsXCI6IFwiL2VjaGFydC9lY2hhcnRkYXRhc2V0L1wiLCBcImFkZFVybFwiOiBcIi9lY2hhcnQvZWNoYXJ0ZGF0YXNldC9hZGQvXCIsIFwiYnJlYWRjcnVtYnNcIjogW3tcIm5hbWVcIjogXCJTbWFydENoYXJ0XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIn0sIHtcIm5hbWVcIjogXCIwMFxcdTY1NzBcXHU2MzZlXFx1OTZjNlwiLCBcImljb25cIjogXCJmYXIgZmEtY2lyY2xlXCJ9XSwgXCJlaWRcIjogMTAwMn0sIHtcIm5hbWVcIjogXCIwMVxcdTRlZWFcXHU4ODY4XFx1NzZkOFwiLCBcImljb25cIjogXCJmYXIgZmEtY2lyY2xlXCIsIFwidXJsXCI6IFwiL2VjaGFydC9lY2hhcnRkYXNoYm9hcmRzZXR1cF92Mi9cIiwgXCJhZGRVcmxcIjogXCIvZWNoYXJ0L2VjaGFydGRhc2hib2FyZHNldHVwX3YyL2FkZC9cIiwgXCJicmVhZGNydW1ic1wiOiBbe1wibmFtZVwiOiBcIlNtYXJ0Q2hhcnRcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwifSwge1wibmFtZVwiOiBcIjAxXFx1NGVlYVxcdTg4NjhcXHU3NmQ4XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIn1dLCBcImVpZFwiOiAxMDAzfSwge1wibmFtZVwiOiBcIjA1XFx1OGZkZVxcdTYzYTVcXHU2YzYwXCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIiwgXCJ1cmxcIjogXCIvZWNoYXJ0L2Ric2V0dXAvXCIsIFwiYWRkVXJsXCI6IFwiL2VjaGFydC9kYnNldHVwL2FkZC9cIiwgXCJicmVhZGNydW1ic1wiOiBbe1wibmFtZVwiOiBcIlNtYXJ0Q2hhcnRcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwifSwge1wibmFtZVwiOiBcIjA1XFx1OGZkZVxcdTYzYTVcXHU2YzYwXCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIn1dLCBcImVpZFwiOiAxMDA0fSwge1wibmFtZVwiOiBcIjA3XFx1OTg3OVxcdTc2ZWVcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwiLCBcInVybFwiOiBcIi9lY2hhcnQvcHJvamVjdGxpc3QvXCIsIFwiYWRkVXJsXCI6IFwiL2VjaGFydC9wcm9qZWN0bGlzdC9hZGQvXCIsIFwiYnJlYWRjcnVtYnNcIjogW3tcIm5hbWVcIjogXCJTbWFydENoYXJ0XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIn0sIHtcIm5hbWVcIjogXCIwN1xcdTk4NzlcXHU3NmVlXCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIn1dLCBcImVpZFwiOiAxMDA1fSwge1wibmFtZVwiOiBcIlxcdThiYmZcXHU5NWVlXFx1OGJiMFxcdTVmNTVcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwiLCBcInVybFwiOiBcIi9lY2hhcnQvdmlzaXRsb2cvXCIsIFwiYWRkVXJsXCI6IFwiL2VjaGFydC92aXNpdGxvZy9hZGQvXCIsIFwiYnJlYWRjcnVtYnNcIjogW3tcIm5hbWVcIjogXCJTbWFydENoYXJ0XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIn0sIHtcIm5hbWVcIjogXCJcXHU4YmJmXFx1OTVlZVxcdThiYjBcXHU1ZjU1XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIn1dLCBcImVpZFwiOiAxMDA2fSwge1wibmFtZVwiOiBcIlxcdTk1MTlcXHU4YmVmXFx1NjVlNVxcdTVmZDdcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwiLCBcInVybFwiOiBcIi9lY2hhcnQvZXJyb3Jsb2cvXCIsIFwiYWRkVXJsXCI6IFwiL2VjaGFydC9lcnJvcmxvZy9hZGQvXCIsIFwiYnJlYWRjcnVtYnNcIjogW3tcIm5hbWVcIjogXCJTbWFydENoYXJ0XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIn0sIHtcIm5hbWVcIjogXCJcXHU5NTE5XFx1OGJlZlxcdTY1ZTVcXHU1ZmQ3XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIn1dLCBcImVpZFwiOiAxMDA3fV0sIFwiZWlkXCI6IDEwMDF9LCB7XCJuYW1lXCI6IFwiXFx1NmMxNFxcdThjNjFcXHU2NTcwXFx1NjM2ZVxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIiwgXCJtb2RlbHNcIjogW3tcIm5hbWVcIjogXCJcXHU2YzE0XFx1OGM2MVxcdTYzMDdcXHU2NTcwXFx1NGZlMVxcdTYwNmZcXHU3YmExXFx1NzQwNlwiLCBcImljb25cIjogXCJmYXIgZmEtY2lyY2xlXCIsIFwidXJsXCI6IFwiL2luZm9tL2FkdmljZS9cIiwgXCJhZGRVcmxcIjogXCIvaW5mb20vYWR2aWNlL2FkZC9cIiwgXCJicmVhZGNydW1ic1wiOiBbe1wibmFtZVwiOiBcIlxcdTZjMTRcXHU4YzYxXFx1NjU3MFxcdTYzNmVcXHU3YmExXFx1NzQwNlwiLCBcImljb25cIjogXCJmYXIgZmEtY2lyY2xlXCJ9LCB7XCJuYW1lXCI6IFwiXFx1NmMxNFxcdThjNjFcXHU2MzA3XFx1NjU3MFxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwifV0sIFwiZWlkXCI6IDEwMDl9LCB7XCJuYW1lXCI6IFwiXFx1NmMxNFxcdThjNjFcXHU4ZDQ0XFx1NjU5OVxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwiLCBcInVybFwiOiBcIi9pbmZvbS9saWIvXCIsIFwiYWRkVXJsXCI6IFwiL2luZm9tL2xpYi9hZGQvXCIsIFwiYnJlYWRjcnVtYnNcIjogW3tcIm5hbWVcIjogXCJcXHU2YzE0XFx1OGM2MVxcdTY1NzBcXHU2MzZlXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwifSwge1wibmFtZVwiOiBcIlxcdTZjMTRcXHU4YzYxXFx1OGQ0NFxcdTY1OTlcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIn1dLCBcImVpZFwiOiAxMDEwfV0sIFwiZWlkXCI6IDEwMDh9LCB7XCJuYW1lXCI6IFwiXFx1NzZkMVxcdTZkNGJcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIiwgXCJtb2RlbHNcIjogW3tcIm5hbWVcIjogXCJcXHU2NTcwXFx1NjM2ZVxcdTVlOTRcXHU3NTI4XFx1NGZlMVxcdTYwNmZcXHU3YmExXFx1NzQwNlwiLCBcImljb25cIjogXCJmYXIgZmEtY2lyY2xlXCIsIFwidXJsXCI6IFwiL3N0YXRpb24vdXNhZ2VzL1wiLCBcImFkZFVybFwiOiBcIi9zdGF0aW9uL3VzYWdlcy9hZGQvXCIsIFwiYnJlYWRjcnVtYnNcIjogW3tcIm5hbWVcIjogXCJcXHU3NmQxXFx1NmQ0YlxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwifSwge1wibmFtZVwiOiBcIlxcdTY1NzBcXHU2MzZlXFx1NWU5NFxcdTc1MjhcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIn1dLCBcImVpZFwiOiAxMDEyfSwge1wibmFtZVwiOiBcIlxcdTc2ZDFcXHU2ZDRiXFx1NTZlMFxcdTViNTBcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIiwgXCJ1cmxcIjogXCIvc3RhdGlvbi9mYWN0b3JzL1wiLCBcImFkZFVybFwiOiBcIi9zdGF0aW9uL2ZhY3RvcnMvYWRkL1wiLCBcImJyZWFkY3J1bWJzXCI6IFt7XCJuYW1lXCI6IFwiXFx1NzZkMVxcdTZkNGJcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIn0sIHtcIm5hbWVcIjogXCJcXHU3NmQxXFx1NmQ0YlxcdTU2ZTBcXHU1YjUwXFx1NGZlMVxcdTYwNmZcXHU3YmExXFx1NzQwNlwiLCBcImljb25cIjogXCJmYXIgZmEtY2lyY2xlXCJ9XSwgXCJlaWRcIjogMTAxM30sIHtcIm5hbWVcIjogXCJcXHU3NmQxXFx1NmQ0YlxcdTdhZDlcXHU3MGI5XFx1NGZlMVxcdTYwNmZcXHU3YmExXFx1NzQwNlwiLCBcImljb25cIjogXCJmYXIgZmEtY2lyY2xlXCIsIFwidXJsXCI6IFwiL3N0YXRpb24vc2l0ZXMvXCIsIFwiYWRkVXJsXCI6IFwiL3N0YXRpb24vc2l0ZXMvYWRkL1wiLCBcImJyZWFkY3J1bWJzXCI6IFt7XCJuYW1lXCI6IFwiXFx1NzZkMVxcdTZkNGJcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIn0sIHtcIm5hbWVcIjogXCJcXHU3NmQxXFx1NmQ0YlxcdTdhZDlcXHU3MGI5XFx1NGZlMVxcdTYwNmZcXHU3YmExXFx1NzQwNlwiLCBcImljb25cIjogXCJmYXIgZmEtY2lyY2xlXCJ9XSwgXCJlaWRcIjogMTAxNH1dLCBcImVpZFwiOiAxMDExfSwge1wibmFtZVwiOiBcIlxcdThiYTRcXHU4YmMxXFx1NTQ4Y1xcdTYzODhcXHU2NzQzXCIsIFwiaWNvblwiOiBcImZhcyBmYS1zaGllbGQtYWx0XCIsIFwibW9kZWxzXCI6IFt7XCJuYW1lXCI6IFwiXFx1NzUyOFxcdTYyMzdcIiwgXCJpY29uXCI6IFwiZmFyIGZhLXVzZXJcIiwgXCJ1cmxcIjogXCIvYXV0aC91c2VyL1wiLCBcImFkZFVybFwiOiBcIi9hdXRoL3VzZXIvYWRkL1wiLCBcImJyZWFkY3J1bWJzXCI6IFt7XCJuYW1lXCI6IFwiXFx1OGJhNFxcdThiYzFcXHU1NDhjXFx1NjM4OFxcdTY3NDNcIiwgXCJpY29uXCI6IFwiZmFzIGZhLXNoaWVsZC1hbHRcIn0sIHtcIm5hbWVcIjogXCJcXHU3NTI4XFx1NjIzN1wiLCBcImljb25cIjogXCJmYXIgZmEtdXNlclwifV0sIFwiZWlkXCI6IDEwMTZ9LCB7XCJuYW1lXCI6IFwiXFx1N2VjNFwiLCBcImljb25cIjogXCJmYXMgZmEtdXNlcnMtY29nXCIsIFwidXJsXCI6IFwiL2F1dGgvZ3JvdXAvXCIsIFwiYWRkVXJsXCI6IFwiL2F1dGgvZ3JvdXAvYWRkL1wiLCBcImJyZWFkY3J1bWJzXCI6IFt7XCJuYW1lXCI6IFwiXFx1OGJhNFxcdThiYzFcXHU1NDhjXFx1NjM4OFxcdTY3NDNcIiwgXCJpY29uXCI6IFwiZmFzIGZhLXNoaWVsZC1hbHRcIn0sIHtcIm5hbWVcIjogXCJcXHU3ZWM0XCIsIFwiaWNvblwiOiBcImZhcyBmYS11c2Vycy1jb2dcIn1dLCBcImVpZFwiOiAxMDE3fV0sIFwiZWlkXCI6IDEwMTV9XSIsInNpbXBsZXVpXzIwMjIwMzEzIjp0cnVlfQ==', '2022-03-27 19:31:46.936210');
INSERT INTO `django_session` VALUES ('e9r3wf8gaoo3sn7plzxegxhnmiazl7ad', 'OWM1YTQwZWQ2ZjJmNjQ3ZDA4YTQ5MjVlY2I5MjU1ZWQzZTBhMzI1MDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIzYzg0OTg1NWNkOGExYzZkNDBjNDE5YTE4MWIxYjgzNjI4MmNkZGJiIiwiX21lbnVzIjoiW3tcIm5hbWVcIjogXCJcXHU3NmQxXFx1NmQ0YlxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwiLCBcIm1vZGVsc1wiOiBbe1wibmFtZVwiOiBcIlxcdTY1NzBcXHU2MzZlXFx1NWU5NFxcdTc1MjhcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIiwgXCJ1cmxcIjogXCIvc3RhdGlvbi91c2FnZXMvXCIsIFwiYWRkVXJsXCI6IFwiL3N0YXRpb24vdXNhZ2VzL2FkZC9cIiwgXCJicmVhZGNydW1ic1wiOiBbe1wibmFtZVwiOiBcIlxcdTc2ZDFcXHU2ZDRiXFx1NGZlMVxcdTYwNmZcXHU3YmExXFx1NzQwNlwiLCBcImljb25cIjogXCJmYXIgZmEtY2lyY2xlXCJ9LCB7XCJuYW1lXCI6IFwiXFx1NjU3MFxcdTYzNmVcXHU1ZTk0XFx1NzUyOFxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwifV0sIFwiZWlkXCI6IDEwMDJ9LCB7XCJuYW1lXCI6IFwiXFx1NzZkMVxcdTZkNGJcXHU1NmUwXFx1NWI1MFxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwiLCBcInVybFwiOiBcIi9zdGF0aW9uL2ZhY3RvcnMvXCIsIFwiYWRkVXJsXCI6IFwiL3N0YXRpb24vZmFjdG9ycy9hZGQvXCIsIFwiYnJlYWRjcnVtYnNcIjogW3tcIm5hbWVcIjogXCJcXHU3NmQxXFx1NmQ0YlxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwifSwge1wibmFtZVwiOiBcIlxcdTc2ZDFcXHU2ZDRiXFx1NTZlMFxcdTViNTBcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIn1dLCBcImVpZFwiOiAxMDAzfSwge1wibmFtZVwiOiBcIlxcdTc2ZDFcXHU2ZDRiXFx1N2FkOVxcdTcwYjlcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIiwgXCJ1cmxcIjogXCIvc3RhdGlvbi9zaXRlcy9cIiwgXCJhZGRVcmxcIjogXCIvc3RhdGlvbi9zaXRlcy9hZGQvXCIsIFwiYnJlYWRjcnVtYnNcIjogW3tcIm5hbWVcIjogXCJcXHU3NmQxXFx1NmQ0YlxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwifSwge1wibmFtZVwiOiBcIlxcdTc2ZDFcXHU2ZDRiXFx1N2FkOVxcdTcwYjlcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIn1dLCBcImVpZFwiOiAxMDA0fV0sIFwiZWlkXCI6IDEwMDF9LCB7XCJuYW1lXCI6IFwiXFx1OGJhNFxcdThiYzFcXHU1NDhjXFx1NjM4OFxcdTY3NDNcIiwgXCJpY29uXCI6IFwiZmFzIGZhLXNoaWVsZC1hbHRcIiwgXCJtb2RlbHNcIjogW3tcIm5hbWVcIjogXCJcXHU3NTI4XFx1NjIzN1wiLCBcImljb25cIjogXCJmYXIgZmEtdXNlclwiLCBcInVybFwiOiBcIi9hdXRoL3VzZXIvXCIsIFwiYWRkVXJsXCI6IFwiL2F1dGgvdXNlci9hZGQvXCIsIFwiYnJlYWRjcnVtYnNcIjogW3tcIm5hbWVcIjogXCJcXHU4YmE0XFx1OGJjMVxcdTU0OGNcXHU2Mzg4XFx1Njc0M1wiLCBcImljb25cIjogXCJmYXMgZmEtc2hpZWxkLWFsdFwifSwge1wibmFtZVwiOiBcIlxcdTc1MjhcXHU2MjM3XCIsIFwiaWNvblwiOiBcImZhciBmYS11c2VyXCJ9XSwgXCJlaWRcIjogMTAwNn0sIHtcIm5hbWVcIjogXCJcXHU3ZWM0XCIsIFwiaWNvblwiOiBcImZhcyBmYS11c2Vycy1jb2dcIiwgXCJ1cmxcIjogXCIvYXV0aC9ncm91cC9cIiwgXCJhZGRVcmxcIjogXCIvYXV0aC9ncm91cC9hZGQvXCIsIFwiYnJlYWRjcnVtYnNcIjogW3tcIm5hbWVcIjogXCJcXHU4YmE0XFx1OGJjMVxcdTU0OGNcXHU2Mzg4XFx1Njc0M1wiLCBcImljb25cIjogXCJmYXMgZmEtc2hpZWxkLWFsdFwifSwge1wibmFtZVwiOiBcIlxcdTdlYzRcIiwgXCJpY29uXCI6IFwiZmFzIGZhLXVzZXJzLWNvZ1wifV0sIFwiZWlkXCI6IDEwMDd9XSwgXCJlaWRcIjogMTAwNX1dIiwic2ltcGxldWlfMjAyMjAzMDgiOnRydWV9', '2022-03-22 19:10:11.121777');
INSERT INTO `django_session` VALUES ('l65zj2k3whrgtmjwcpr1aruimma679xl', 'YTFiNWZiYmU3Yzc4NWI4YmU1NmUxMjk4NDYyMmQ3ZmJhNWJlOGVlMDp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIyYWY1MmJlNmE1NDE5MmYzNTVkN2RjZGIzYzgwMzE1YjU3NmZmMTJjIiwiX21lbnVzIjoiW3tcIm5hbWVcIjogXCJcXHU2YzE0XFx1OGM2MVxcdTY1NzBcXHU2MzZlXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwiLCBcIm1vZGVsc1wiOiBbe1wibmFtZVwiOiBcIlxcdTZjMTRcXHU4YzYxXFx1NjMwN1xcdTY1NzBcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIiwgXCJ1cmxcIjogXCIvaW5mb20vYWR2aWNlL1wiLCBcImFkZFVybFwiOiBcIi9pbmZvbS9hZHZpY2UvYWRkL1wiLCBcImJyZWFkY3J1bWJzXCI6IFt7XCJuYW1lXCI6IFwiXFx1NmMxNFxcdThjNjFcXHU2NTcwXFx1NjM2ZVxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIn0sIHtcIm5hbWVcIjogXCJcXHU2YzE0XFx1OGM2MVxcdTYzMDdcXHU2NTcwXFx1NGZlMVxcdTYwNmZcXHU3YmExXFx1NzQwNlwiLCBcImljb25cIjogXCJmYXIgZmEtY2lyY2xlXCJ9XSwgXCJlaWRcIjogMTAwMn0sIHtcIm5hbWVcIjogXCJcXHU2YzE0XFx1OGM2MVxcdThkNDRcXHU2NTk5XFx1NGZlMVxcdTYwNmZcXHU3YmExXFx1NzQwNlwiLCBcImljb25cIjogXCJmYXIgZmEtY2lyY2xlXCIsIFwidXJsXCI6IFwiL2luZm9tL2xpYi9cIiwgXCJhZGRVcmxcIjogXCIvaW5mb20vbGliL2FkZC9cIiwgXCJicmVhZGNydW1ic1wiOiBbe1wibmFtZVwiOiBcIlxcdTZjMTRcXHU4YzYxXFx1NjU3MFxcdTYzNmVcXHU3YmExXFx1NzQwNlwiLCBcImljb25cIjogXCJmYXIgZmEtY2lyY2xlXCJ9LCB7XCJuYW1lXCI6IFwiXFx1NmMxNFxcdThjNjFcXHU4ZDQ0XFx1NjU5OVxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwifV0sIFwiZWlkXCI6IDEwMDN9XSwgXCJlaWRcIjogMTAwMX0sIHtcIm5hbWVcIjogXCJcXHU3NmQxXFx1NmQ0YlxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwiLCBcIm1vZGVsc1wiOiBbe1wibmFtZVwiOiBcIlxcdTY1NzBcXHU2MzZlXFx1NWU5NFxcdTc1MjhcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIiwgXCJ1cmxcIjogXCIvc3RhdGlvbi91c2FnZXMvXCIsIFwiYWRkVXJsXCI6IFwiL3N0YXRpb24vdXNhZ2VzL2FkZC9cIiwgXCJicmVhZGNydW1ic1wiOiBbe1wibmFtZVwiOiBcIlxcdTc2ZDFcXHU2ZDRiXFx1NGZlMVxcdTYwNmZcXHU3YmExXFx1NzQwNlwiLCBcImljb25cIjogXCJmYXIgZmEtY2lyY2xlXCJ9LCB7XCJuYW1lXCI6IFwiXFx1NjU3MFxcdTYzNmVcXHU1ZTk0XFx1NzUyOFxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwifV0sIFwiZWlkXCI6IDEwMDV9LCB7XCJuYW1lXCI6IFwiXFx1NzZkMVxcdTZkNGJcXHU1NmUwXFx1NWI1MFxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwiLCBcInVybFwiOiBcIi9zdGF0aW9uL2ZhY3RvcnMvXCIsIFwiYWRkVXJsXCI6IFwiL3N0YXRpb24vZmFjdG9ycy9hZGQvXCIsIFwiYnJlYWRjcnVtYnNcIjogW3tcIm5hbWVcIjogXCJcXHU3NmQxXFx1NmQ0YlxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwifSwge1wibmFtZVwiOiBcIlxcdTc2ZDFcXHU2ZDRiXFx1NTZlMFxcdTViNTBcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIn1dLCBcImVpZFwiOiAxMDA2fSwge1wibmFtZVwiOiBcIlxcdTc2ZDFcXHU2ZDRiXFx1N2FkOVxcdTcwYjlcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIiwgXCJ1cmxcIjogXCIvc3RhdGlvbi9zaXRlcy9cIiwgXCJhZGRVcmxcIjogXCIvc3RhdGlvbi9zaXRlcy9hZGQvXCIsIFwiYnJlYWRjcnVtYnNcIjogW3tcIm5hbWVcIjogXCJcXHU3NmQxXFx1NmQ0YlxcdTRmZTFcXHU2MDZmXFx1N2JhMVxcdTc0MDZcIiwgXCJpY29uXCI6IFwiZmFyIGZhLWNpcmNsZVwifSwge1wibmFtZVwiOiBcIlxcdTc2ZDFcXHU2ZDRiXFx1N2FkOVxcdTcwYjlcXHU0ZmUxXFx1NjA2ZlxcdTdiYTFcXHU3NDA2XCIsIFwiaWNvblwiOiBcImZhciBmYS1jaXJjbGVcIn1dLCBcImVpZFwiOiAxMDA3fV0sIFwiZWlkXCI6IDEwMDR9LCB7XCJuYW1lXCI6IFwiXFx1OGJhNFxcdThiYzFcXHU1NDhjXFx1NjM4OFxcdTY3NDNcIiwgXCJpY29uXCI6IFwiZmFzIGZhLXNoaWVsZC1hbHRcIiwgXCJtb2RlbHNcIjogW3tcIm5hbWVcIjogXCJcXHU3NTI4XFx1NjIzN1wiLCBcImljb25cIjogXCJmYXIgZmEtdXNlclwiLCBcInVybFwiOiBcIi9hdXRoL3VzZXIvXCIsIFwiYWRkVXJsXCI6IFwiL2F1dGgvdXNlci9hZGQvXCIsIFwiYnJlYWRjcnVtYnNcIjogW3tcIm5hbWVcIjogXCJcXHU4YmE0XFx1OGJjMVxcdTU0OGNcXHU2Mzg4XFx1Njc0M1wiLCBcImljb25cIjogXCJmYXMgZmEtc2hpZWxkLWFsdFwifSwge1wibmFtZVwiOiBcIlxcdTc1MjhcXHU2MjM3XCIsIFwiaWNvblwiOiBcImZhciBmYS11c2VyXCJ9XSwgXCJlaWRcIjogMTAwOX0sIHtcIm5hbWVcIjogXCJcXHU3ZWM0XCIsIFwiaWNvblwiOiBcImZhcyBmYS11c2Vycy1jb2dcIiwgXCJ1cmxcIjogXCIvYXV0aC9ncm91cC9cIiwgXCJhZGRVcmxcIjogXCIvYXV0aC9ncm91cC9hZGQvXCIsIFwiYnJlYWRjcnVtYnNcIjogW3tcIm5hbWVcIjogXCJcXHU4YmE0XFx1OGJjMVxcdTU0OGNcXHU2Mzg4XFx1Njc0M1wiLCBcImljb25cIjogXCJmYXMgZmEtc2hpZWxkLWFsdFwifSwge1wibmFtZVwiOiBcIlxcdTdlYzRcIiwgXCJpY29uXCI6IFwiZmFzIGZhLXVzZXJzLWNvZ1wifV0sIFwiZWlkXCI6IDEwMTB9XSwgXCJlaWRcIjogMTAwOH1dIiwic2ltcGxldWlfMjAyMjAzMTMiOnRydWV9', '2022-03-27 22:14:46.007412');

-- ----------------------------
-- Table structure for infom_advice
-- ----------------------------
DROP TABLE IF EXISTS `infom_advice`;
CREATE TABLE `infom_advice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clothes_inf` varchar(128) NOT NULL,
  `uv_inf` varchar(128) NOT NULL,
  `carWash_inf` varchar(128) NOT NULL,
  `ill_inf` varchar(128) NOT NULL,
  `city_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `infom_advice_city_id_2919da93_fk_station_sites_id` (`city_id`),
  CONSTRAINT `infom_advice_city_id_2919da93_fk_station_sites_id` FOREIGN KEY (`city_id`) REFERENCES `station_sites` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of infom_advice
-- ----------------------------
INSERT INTO `infom_advice` VALUES ('1', '薄衣服', '弱', '适宜', '弱', '3');
INSERT INTO `infom_advice` VALUES ('2', '厚衣服', '适中', '不适宜', '弱', '3');
INSERT INTO `infom_advice` VALUES ('3', '厚衣服', '强', '适宜', '弱', '5');

-- ----------------------------
-- Table structure for infom_lib
-- ----------------------------
DROP TABLE IF EXISTS `infom_lib`;
CREATE TABLE `infom_lib` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `earth_lib` varchar(128) NOT NULL,
  `sky_lib` varchar(128) NOT NULL,
  `radiation_lib` varchar(128) NOT NULL,
  `radar_lib` varchar(128) NOT NULL,
  `satellite_lib` varchar(128) NOT NULL,
  `num_lib` varchar(128) NOT NULL,
  `city_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `infom_lib_city_id_e2557c31_fk_station_sites_id` (`city_id`),
  CONSTRAINT `infom_lib_city_id_e2557c31_fk_station_sites_id` FOREIGN KEY (`city_id`) REFERENCES `station_sites` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of infom_lib
-- ----------------------------
INSERT INTO `infom_lib` VALUES ('1', '自己加一些材料名字', '自己加一些材料名字', '自己加一些材料名字', '自己加一些材料名字', '自己加一些材料名字', '自己加一些材料名字', '1');

-- ----------------------------
-- Table structure for station_factors
-- ----------------------------
DROP TABLE IF EXISTS `station_factors`;
CREATE TABLE `station_factors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time` datetime(6) NOT NULL,
  `lowest_temp` double NOT NULL,
  `highest_temp` double NOT NULL,
  `rainfall` varchar(128) NOT NULL,
  `wind` int(11) NOT NULL,
  `site_name_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `station_factors_site_name_id_5c2d13ba_fk_station_sites_id` (`site_name_id`),
  CONSTRAINT `station_factors_site_name_id_5c2d13ba_fk_station_sites_id` FOREIGN KEY (`site_name_id`) REFERENCES `station_sites` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of station_factors
-- ----------------------------
INSERT INTO `station_factors` VALUES ('1', '2022-03-13 21:15:28.183081', '10', '20', '20mm', '3', '2');
INSERT INTO `station_factors` VALUES ('2', '2022-03-13 21:17:30.902114', '20', '24', '强降水', '4', '4');

-- ----------------------------
-- Table structure for station_sites
-- ----------------------------
DROP TABLE IF EXISTS `station_sites`;
CREATE TABLE `station_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_name` varchar(128) NOT NULL,
  `site_props` int(11) NOT NULL,
  `longitude` varchar(128) NOT NULL,
  `latitude` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of station_sites
-- ----------------------------
INSERT INTO `station_sites` VALUES ('1', '改成贵州的相关数据', '3', '117°09\'32.14\"', '39°05\'04.20\"');
INSERT INTO `station_sites` VALUES ('2', '云岩', '0', '117°09\'32.04\"', '26°33′~41′');
INSERT INTO `station_sites` VALUES ('3', '南明', '1', '117°09\'32.04\"', '26°33′~41′');
INSERT INTO `station_sites` VALUES ('4', '贵阳', '2', '117°09\'32.04\"', '39°05\'04.20\"');
INSERT INTO `station_sites` VALUES ('5', '小河', '3', '117°09\'32.04\"', '26°33′~41′');

-- ----------------------------
-- Table structure for station_usages
-- ----------------------------
DROP TABLE IF EXISTS `station_usages`;
CREATE TABLE `station_usages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_name` varchar(128) NOT NULL,
  `app_details` longtext NOT NULL,
  `developer` varchar(128) NOT NULL,
  `tel` varchar(11) NOT NULL,
  `auth_time` datetime(6) NOT NULL,
  `site_name_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `station_usages_site_name_id_ce362dc7_fk_station_sites_id` (`site_name_id`),
  CONSTRAINT `station_usages_site_name_id_ce362dc7_fk_station_sites_id` FOREIGN KEY (`site_name_id`) REFERENCES `station_sites` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of station_usages
-- ----------------------------
INSERT INTO `station_usages` VALUES ('1', 'ios天气应用', 'ios天气是中国支持城市最多的天气预报软件。全球约5亿人在使用的天气APP，支持196个国家70多万个城市及地区的天气查询，精准定位及时推送。', '北京市朝阳区来广营东路融新科技', '010-8479838', '2022-01-11 19:05:46.000000', '5');
INSERT INTO `station_usages` VALUES ('2', '嘻嘻天气', '嘻嘻', '嘻嘻科技公司', '010-9898292', '2022-03-08 22:57:03.000000', '2');
INSERT INTO `station_usages` VALUES ('3', '华为天气应用', '。。', '。。', '11111111111', '2022-03-08 06:00:00.000000', '2');
INSERT INTO `station_usages` VALUES ('4', '墨迹天气', '自己找一些靠谱的数据加进去即可', '11', '11111111111', '2022-03-10 00:00:00.000000', '3');

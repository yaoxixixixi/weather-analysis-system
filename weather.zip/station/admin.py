from station.models import *
from django.contrib import admin

from .models import *
from import_export import resources


# Register your models here.
@admin.register(Sites)
class SitesAdmin(admin.ModelAdmin):
    list_display = ('site_name', 'site_props', 'longitude', 'latitude')
    # 需要搜索的字段
    search_fields = ('site_name',)
    

    list_per_page = 20

class ProxyResource(resources.ModelResource):
    class Meta:
        model = Factors

@admin.register(Factors)
class FactorsAdmin(admin.ModelAdmin):
    resource_class = ProxyResource
    list_display = ('site_name', 'time','lowest_temp', 'highest_temp','rainfall','wind')
    list_per_page = 20

@admin.register(Usages)
class UsagesAdmin(admin.ModelAdmin):
    list_display = ('site_name','app_name', 'app_details','developer', 'tel','auth_time')
   
    list_per_page = 20

    '''设置过滤选项'''
    list_filter = ('developer',)
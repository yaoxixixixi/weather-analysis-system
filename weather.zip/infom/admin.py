from station.models import *
from django.contrib import admin

from .models import *
from import_export import resources


# Register your models here.
@admin.register(Lib)
class LibAdmin(admin.ModelAdmin):
    list_display = ('city', 'earth_lib', 'sky_lib', 'radiation_lib','radar_lib','satellite_lib','num_lib')
    # 需要搜索的字段
    search_fields = ('city',)

    list_per_page = 20

class ProxyResource(resources.ModelResource):
    class Meta:
        model = Advice

@admin.register(Advice)
class AdviceAdmin(admin.ModelAdmin):
    resource_class = ProxyResource
    list_display = ('city', 'clothes_inf','uv_inf', 'carWash_inf','ill_inf')
    list_per_page = 20
    list_filter = ('uv_inf','carWash_inf')
